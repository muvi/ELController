/*
 * hv_dc_supply.h
 *
 * Created: 09.07.2022 01:29:59
 *  Author: Christian
 */ 


#ifndef HV_DC_SUPPLY_H_
#define HV_DC_SUPPLY_H_

#include <atmel_start.h>
#include <utils_ringbuffer.h>
#include <adc_util.h>

void hv_dc_supply_enable_adc();
void hv_dc_supply_disable_adc();

#endif /* HV_DC_SUPPLY_H_ */