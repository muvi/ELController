/*
 * hv_dc_supply.c
 *
 * Created: 09.07.2022 01:30:13
 *  Author: Christian
 */ 

#include <hv_dc_supply.h>

void hv_dc_supply_sense(const struct adc_async_descriptor *const descr, const uint8_t channel) {
	
}

void hv_dc_supply_enable_adc() {
	gpio_set_pin_direction(PWR_SENSE, GPIO_DIRECTION_OFF);
	gpio_set_pin_function(PWR_SENSE, PINMUX_PA02B_ADC_AIN0);

	gpio_set_pin_direction(HV_SENSE, GPIO_DIRECTION_OFF);
	gpio_set_pin_function(HV_SENSE, PINMUX_PA03B_ADC_AIN1);
	
	adc_async_set_inputs(&ADC_0, ADC_MUXPOS_AIN1, ADC_MUXNEG_AIN0, 0);
	
	adc_async_register_callback(&ADC_0, 0, ADC_ASYNC_CONVERT_CB, hv_dc_supply_sense);
	adc_async_enable_channel(&ADC_0, 0);
}

void hv_dc_supply_disable_adc() {
	adc_async_disable_channel(&ADC_0, 0);
	
	gpio_set_pin_function(PWR_SENSE, GPIO_PIN_FUNCTION_OFF);
	gpio_set_pin_function(HV_SENSE, GPIO_PIN_FUNCTION_OFF);
}