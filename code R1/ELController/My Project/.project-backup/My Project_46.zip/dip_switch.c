/*
 * dip_switch.c
 *
 * Created: 29.06.2022 17:58:34
 *  Author: Christian
 */ 
#include <dip_switch.h>

#define DIP_SWITCH_VALUES_PER_CHANNEL 16
#define DIP_SWITCH_BITS 4
const uint16_t DIP_SWITCH_THRESHOLDS[DIP_SWITCH_VALUES_PER_CHANNEL] = {0x000, 0x0DC, 0x292, 0x41D, 0x54E, 0x665, 0x793, 0x8AB, 0x9B8, 0xAB8, 0xB94, 0xC5A, 0xCE6, 0xD75, 0xE13, 0xEA7};

uint8_t dip_switch_read_group() {
	uint16_t data;
	adc_sync_read_channel(&ADC_0, 0, (uint8_t*) (&data), 2);
	
	uint8_t result = 0;
	uint8_t pos = 0;
	for (int i = DIP_SWITCH_BITS-1; i >= 0; i--) {
		pos |= 1 << i;
		if (data < DIP_SWITCH_THRESHOLDS[pos]) {
			result |= (1 << i);
			pos ^= (1 << i);
		}
	}
	
	return result;
}

uint16_t dip_switch_read() {
	return dip_switch_read_group();
}
