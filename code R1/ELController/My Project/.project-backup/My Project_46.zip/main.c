#include <atmel_start.h>
#include <io_util.h>
#include <dmx.h>
#include <dip_switch.h>

volatile int state = 1;
volatile bool on = true;

void btn1_pressed() {
	state = 1;
}

void btn2_pressed() {
	state = 2;
}

void btn3_pressed() {
	state = 3;
}

void SysTick_Handler() {
	on = !on;

	uint16_t dip = dip_switch_read();
	
	gpio_set_pin_level(LED2, dip >= 0b1100);
}

void init() {
	gpio_set_pin_drive_strength(LED1);
	gpio_set_pin_drive_strength(LED2);
	
	ext_irq_register(BTN1, btn1_pressed);
	ext_irq_register(BTN2, btn2_pressed);
	ext_irq_register(BTN3, btn3_pressed);
	
	dmx_set_address(1);
	dmx_init(&USART_0);
	
	adc_sync_enable_channel(&ADC_0, 0);
	
	SysTick_Config(10000000);
}

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	init();
	//bool drive_strength = gpio_get_pin_drive_strength(LED2);

	while (1) {
	}
}
