/*
 * dmx.c
 *
 * Created: 28.06.2022 20:41:10
 *  Author: Christian
 */ 
#include <dmx.h>


volatile unsigned short dmxNextAddress = 1;
unsigned short dmxStartAddress = 1;
unsigned short currentChannel = 0;

void dmx_error(const struct usart_async_descriptor *const descr) {
	currentChannel = 0;
	dmxStartAddress = dmxNextAddress;
}

void dmx_rx(const struct usart_async_descriptor *const descr) {
	//gpio_toggle_pin_level(GPIO5);
	
	if (currentChannel >= dmxStartAddress) {
		if (currentChannel < dmxStartAddress + DMX_CHANNELS) {
			dmx[currentChannel - dmxStartAddress] = descr->rx.buf[(descr->rx.write_index + descr->rx.size) & descr->rx.size];
		}
	}
	if (currentChannel == dmxStartAddress) {
		//gpio_set_pin_level(LED2, false);
	}
	if (currentChannel == dmxStartAddress + DMX_CHANNELS - 1) {
		//gpio_set_pin_level(LED2, true);
		dmx_received();
	}
	currentChannel++;
}

void dmx_set_address(unsigned short address) {
	dmxNextAddress = address;
}

void dmx_init(struct usart_async_descriptor *const uart) {
	NVIC_SetPriority((IRQn_Type) sercom_get_irq_num(uart->device.hw), INTERRUPT_PRIORITY_MEDIUM);
	
	usart_async_register_callback(uart, USART_ASYNC_ERROR_CB, dmx_error);
	usart_async_register_callback(uart, USART_ASYNC_RXC_CB, dmx_rx);
	usart_async_enable(uart);

/*
	NVIC_DisableIRQ(SERCOM5_IRQn);
	NVIC_ClearPendingIRQ(SERCOM5_IRQn);
	NVIC_SetPriority(SERCOM5_IRQn, INTERRUPT_PRIORITY_MEDIUM);
	NVIC_EnableIRQ(SERCOM5_IRQn);
	*/
}