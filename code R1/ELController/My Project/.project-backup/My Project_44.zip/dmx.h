#ifndef DMX_H
#define DMX_H

#include <atmel_start.h>

void dmx_init(struct usart_async_descriptor *const uart);
void dmx_set_address(unsigned short address);

#endif