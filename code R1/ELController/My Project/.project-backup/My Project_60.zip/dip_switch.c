/*
 * dip_switch.c
 *
 * Created: 29.06.2022 17:58:34
 *  Author: Christian
 */ 
#include <dip_switch.h>

#define DIP_SWITCH_VALUES_PER_CHANNEL 16
#define DIP_SWITCH_BITS 4
#define DIP_SWITCH_BLOCKS 3
const uint16_t DIP_SWITCH_THRESHOLDS[DIP_SWITCH_VALUES_PER_CHANNEL] = {0x000, 0x0DC, 0x292, 0x41D, 0x54E, 0x665, 0x793, 0x8AB, 0x9B8, 0xAB8, 0xB94, 0xC5A, 0xCE6, 0xD75, 0xE13, 0xEA7};

volatile uint8_t dip_switch_data_pos = 0;
volatile uint16_t dip_switch_data = 0;
volatile bool dip_switch_reading = false;
void dip_switch_data_ready(uint16_t data);

void dip_switch_deinit() {
	adc_async_disable_channel(&ADC_0, 0);
	
	gpio_set_pin_function(CONFIG1, GPIO_PIN_FUNCTION_OFF);
	gpio_set_pin_function(CONFIG2, GPIO_PIN_FUNCTION_OFF);
	gpio_set_pin_function(CONFIG3, GPIO_PIN_FUNCTION_OFF);

	adc_async_set_input_channels(&ADC_0, 0);
}

uint8_t dip_switch_read_group(uint16_t data) {
	uint8_t result = 0;
	uint8_t pos = 0;
	for (int i = DIP_SWITCH_BITS-1; i >= 0; i--) {
		pos |= 1 << i;
		if (data < DIP_SWITCH_THRESHOLDS[pos]) {
			result |= (1 << (DIP_SWITCH_BITS - 1 - i));
			pos ^= (1 << i);
		}
	}
	
	return result;
}

uint16_t dip_switch_read_buffer(struct ringbuffer* buf) {
	return *((uint16_t*) (buf->buf + ((buf->write_index + buf->size - 1) & buf->size)));
}

void dip_switch_data_read(const struct adc_async_descriptor *const descr, const uint8_t channel) {
	uint8_t nibble = dip_switch_read_group(dip_switch_read_buffer(&(descr->descr_ch->convert)));
	if (!dip_switch_data_pos) {
		dip_switch_data = 0;
	}
	dip_switch_data |= nibble << ((DIP_SWITCH_BLOCKS - dip_switch_data_pos - 1) * DIP_SWITCH_BITS);
	
	dip_switch_data_pos = (dip_switch_data_pos + 1) % DIP_SWITCH_BLOCKS;
	
	if (dip_switch_data_pos) {
		adc_async_start_conversion(&ADC_0);
	} else {
		dip_switch_deinit();
		dip_switch_data_ready(dip_switch_data);
		dip_switch_reading = false;
	}
}

void dip_switch_init() {
	adc_async_set_inputs(&ADC_0, ADC_MUXPOS_AIN4, ADC_MUXNEG_IO_GROUND, 0);
	adc_async_set_input_channels(&ADC_0, 2);
	
	gpio_set_pin_direction(CONFIG1, GPIO_DIRECTION_OFF);
	gpio_set_pin_function(CONFIG1, PINMUX_PA04B_ADC_AIN4);

	gpio_set_pin_direction(CONFIG2, GPIO_DIRECTION_OFF);
	gpio_set_pin_function(CONFIG2, PINMUX_PA05B_ADC_AIN5);

	gpio_set_pin_direction(CONFIG3, GPIO_DIRECTION_OFF);
	gpio_set_pin_function(CONFIG3, PINMUX_PA06B_ADC_AIN6);
	
	adc_async_register_callback(&ADC_0, 0, ADC_ASYNC_CONVERT_CB, dip_switch_data_read);
	adc_async_enable_channel(&ADC_0, 0);
}

void dip_switch_read() {
	if (!dip_switch_reading) {
		dip_switch_reading = true;
		dip_switch_init();
		adc_async_start_conversion(&ADC_0);
	}
}
