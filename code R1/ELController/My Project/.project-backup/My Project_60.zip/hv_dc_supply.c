/*
 * hv_dc_supply.c
 *
 * Created: 09.07.2022 01:30:13
 *  Author: Christian
 */ 

#include <hv_dc_supply.h>

void hv_dc_supply_enable_adc() {
	
}

void hv_dc_supply_disable_adc() {
	
}