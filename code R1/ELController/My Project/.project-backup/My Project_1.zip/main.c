#include <atmel_start.h>
#include <io_util.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	gpio_set_pin_drive_strength(LED0);
	bool drive_strength = gpio_get_pin_drive_strength(LED0);

	/* Replace with your application code */
	while (1) {
		for (int i = 0; i < (drive_strength ? 2000 : 10000); i++) ;
		gpio_toggle_pin_level(LED0);
	}
}
