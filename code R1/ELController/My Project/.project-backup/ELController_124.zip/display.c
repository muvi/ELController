/*
 * display.c
 *
 * Created: 2/6/2023 6:23:25 PM
 *  Author: Christian
 */ 

#include <display.h>

void display_update(uint8_t value) {
	SPI_0_enable();
	
	hri_sercomspi_write_DATA_reg(SERCOM4, value);
	
	SPI_0_disable();
}