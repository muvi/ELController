/*
 * user_settings.h
 *
 * Created: 2/18/2023 5:06:45 PM
 *  Author: Christian
 */ 


#ifndef USER_SETTINGS_H_
#define USER_SETTINGS_H_

#define USER_SETTINGS_MEMORY_SIZE_0 7
#define USER_SETTINGS_MEMORY_SIZE_256 6
#define USER_SETTINGS_MEMORY_SIZE_512 5
#define USER_SETTINGS_MEMORY_SIZE_1024 4
#define USER_SETTINGS_MEMORY_SIZE_2048 3
#define USER_SETTINGS_MEMORY_SIZE_4096 2
#define USER_SETTINGS_MEMORY_SIZE_8192 1
#define USER_SETTINGS_MEMORY_SIZE_16384 0

#define NVM_RWWEE 0x00400000

#define USER_SETTINGS_DMX_ADR 0

static inline void user_settings_write_uint16_t(uint16_t address, uint16_t data) {

}

static inline void user_settings_write_uint8_t(uint16_t address, uint8_t data) {
	
}

static inline uint16_t user_settings_read_uint16_t(uint16_t address) {
	return *((uint16_t*) (NVM_RWWEE + address));
}

static inline uint8_t user_settings_read_uint8_t(uint16_t address) {
	return *((uint8_t*) (NVM_RWWEE + address));
}

static inline uint8_t user_settings_get_NVMCTRL_EEPROM_SIZE() {
	return ((*((uint32_t*) NVMCTRL_FUSES_EEPROM_SIZE_ADDR)) & NVMCTRL_FUSES_EEPROM_SIZE_Msk) >> NVMCTRL_FUSES_EEPROM_SIZE_Pos;
}

static inline uint8_t user_settings_get_NVMCTRL_PARAM_NVMP() {
	return ((NVMCTRL_PARAM_Type*) (NVMCTRL + NVMCTRL_PARAM_OFFSET))->bit.NVMP;
}

static inline uint8_t user_settings_get_NVMCTRL_PARAM_RWWEEP() {
	return ((NVMCTRL_PARAM_Type*) (NVMCTRL + NVMCTRL_PARAM_OFFSET))->bit.RWWEEP;
}

#endif /* USER_SETTINGS_H_ */