/*
 * display.c
 *
 * Created: 2/6/2023 6:23:25 PM
 *  Author: Christian
 */ 

#include <display.h>

#define DISPLAY_COUNT 16

const uint8_t DISPLAY_NUMBERS[DISPLAY_COUNT] = {0b10001000, 0b11011011, 0b10010100, 0b10010001, 0b11000011, 0b10100001, 0b10100000, 0b10011011, 0b10000000, 0b10000001, 0b10000010, 0b11100000, 0b10101100, 0b11010000, 0b10100100, 0b10100110};
#define DISPLAY_DOT 0b01111111
#define DISPLAY_BLANK 0b11111111

const uint8_t DISPLAY_SEGMENTS[DISPLAY_NUMSEGMENTS] = {0b00000000, 0b00000000, 0b00000000, 0b00000000, 0b00000000, 0b00000000, 0b00000011, 0b00001100, 0b00110000};

volatile uint8_t display_current_segment = 0;
volatile uint8_t display_current_digits[DISPLAY_NUMSEGMENTS] = {DISPLAY_BLANK, DISPLAY_BLANK, DISPLAY_BLANK, DISPLAY_BLANK, DISPLAY_BLANK, DISPLAY_BLANK, DISPLAY_BLANK, DISPLAY_BLANK, DISPLAY_BLANK};

void display_init() {
	SPI_0_enable();
}

void display_update_base(uint16_t value, uint8_t base) {
	uint16_t val = value;
	for (int i = DISPLAY_NUMSEGMENTS - 1; i >= 0; i--) {
		display_current_digits[i] = DISPLAY_NUMBERS[val % base];
		val /= base;
	}
	//delete leading zeros
	for (int i = 0; i < DISPLAY_NUMSEGMENTS - 1; i++) {
		if (display_current_digits[i] == DISPLAY_NUMBERS[0]) {
			display_current_digits[i] = DISPLAY_BLANK;
		} else {
			break;
		}
	}
}

void display_update(uint16_t value) {
	display_update_base(value, 10);
}

void display_update_hex(uint16_t value) {
	display_update_base(value, 16);
}

void display_render() {
	display_current_segment = (display_current_segment + 1) % DISPLAY_NUMSEGMENTS;
	uint16_t val = (display_current_digits[display_current_segment] << 8) | DISPLAY_SEGMENTS[display_current_segment];
	SPI_0_write_block(&val, 2);
}