/*
 * adc_lite.h
 *
 * Created: 18.07.2022 22:08:58
 *  Author: Christian
 */ 


#ifndef ADC_LITE_H_
#define ADC_LITE_H_

#include <hal_adc_async.h>

extern struct adc_async_descriptor ADC_0;

void adc_init();


#endif /* ADC_LITE_H_ */