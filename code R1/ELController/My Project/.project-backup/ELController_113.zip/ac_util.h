/*
 * ac_util.h
 *
 * Created: 17.07.2022 19:37:57
 *  Author: Christian
 */ 


#ifndef AC_UTIL_H_
#define AC_UTIL_H_

#include <hri_ac_d21c.h>
#include <hal_ac_async.h>
#include <hal_atomic.h>

#define AC_MUXPOS_AIN0 0x1
#define AC_MUXPOS_AIN1 0x2
#define AC_MUXPOS_AIN2 0x3
#define AC_MUXPOS_AIN3 0x4

#define AC_MUXNEG_AIN0 0x0
#define AC_MUXNEG_AIN1 0x1
#define AC_MUXNEG_AIN2 0x2
#define AC_MUXNEG_AIN3 0x3
#define AC_MUXNEG_GND 0x4
#define AC_MUXNEG_VSCALE 0x5
#define AC_MUXNEG_BANDGAP 0x6
#define AC_MUXNEG_DAC 0x7

void ac_async_set_positive_input(struct ac_async_descriptor *const descr, uint8_t comp, hri_ac_compctrl_reg_t muxpos);

#endif /* AC_UTIL_H_ */