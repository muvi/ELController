/*
 * OutputChannels.h
 *
 * Created: 24.08.2022 20:35:23
 *  Author: Christian
 */ 


#ifndef OUTPUTCHANNELS_H_
#define OUTPUTCHANNELS_H_

#include <atmel_start.h>
#include <hpl_pm_base.h>
#include <tcc_util.h>
#include <interrupt_util.h>
#include <io_util.h>

void output_channels_init();

#endif /* OUTPUTCHANNELS_H_ */