/*
 * display.c
 *
 * Created: 2/6/2023 6:23:25 PM
 *  Author: Christian
 */ 

#include <display.h>

#define DISPLAY_COUNT 36

//const uint8_t DISPLAY_NUMBERS[DISPLAY_COUNT] = {0b10001000, 0b11011011, 0b10010100, 0b10010001, 0b11000011, 0b10100001, 0b10100000, 0b10011011, 0b10000000, 0b10000001, 0b10000010, 0b11100000, 0b10101100, 0b11010000, 0b10100100, 0b10100110};
const uint8_t DISPLAY_NUMBERS[DISPLAY_COUNT] = {0b00000001, 0b01001111, 0b00010010, 0b00000110, 0b01001100, 0b00100100, 0b00100000, 0b00001111, 0b00000000, 0b00000100, 0b00001000, 0b00110000, 0b00110001, 0b01111001, 0b00110000, 0b00111000, 0b00100001, 0b01001000, 0b01111111, 0b01000011, 0b01111111, 0b01110001, 0b01001001, 0b01001001, 0b00000001, 0b00011000, 0b00000001, 0b00011000, 0b00100100, 0b00111111, 0b01000001, 0b01111001, 0b01001001, 0b01111111, 0b01111111, 0b00110111};
#define DISPLAY_BLANK 0b01111111

const uint16_t DISPLAY_SEGMENTS[DISPLAY_NUMSEGMENTS * 2] = {0b1100000000000000, 0b0011000000000000, 0b0000110000000000, 0b0000001100000000, 0b0000000011000000, 0b0000000000110000, 0b0000000000001100, 0b0000000000000011};
//const uint16_t DISPLAY_SEGMENTS[DISPLAY_NUMSEGMENTS * 2] = {0b0000000000000011, 0b0000000000001100, 0b0000000000110000, 0b0000000011000000, 0b0000001100000000, 0b00001100000000000, 0b0011000000000000, 0b1100000000000000};
//const uint16_t DISPLAY_SEGMENTS[DISPLAY_NUMSEGMENTS * 2] = {0b0000000000000011, 0b0000000000001100, 0b0000000000110000, 0b0000000011000000, 0b0000000000000000, 0b00000000000000000, 0b0000000000000000, 0b0000000000000000};

volatile uint8_t display_current_segment = 0;
volatile uint8_t display_current_digits[DISPLAY_NUMSEGMENTS * 2] = {DISPLAY_BLANK, DISPLAY_BLANK, DISPLAY_BLANK, DISPLAY_BLANK, DISPLAY_BLANK, DISPLAY_BLANK, DISPLAY_BLANK, DISPLAY_BLANK};

void display_init() {
	SPI_0_enable();
	gpio_set_pin_function(DISPLAY_SS, GPIO_PIN_FUNCTION_OFF);
	gpio_set_pin_direction(DISPLAY_SS, GPIO_DIRECTION_OUT);
	gpio_set_pin_level(DISPLAY_SS, true);
}

void display_update_base(uint16_t value, uint8_t base) {
	uint16_t val = value;
	for (int i = DISPLAY_NUMSEGMENTS - 1; i >= 0; i--) {
		display_current_digits[i] = DISPLAY_NUMBERS[val % base];// & 0b00000000;
		val /= base;
	}
	//delete leading zeros
	/*
	for (int i = 0; i < DISPLAY_NUMSEGMENTS - 1; i++) {
		if (display_current_digits[i] == DISPLAY_NUMBERS[0]) {
			display_current_digits[i] = DISPLAY_BLANK;
		} else {
			break;
		}
	}
	*/
}

void display_update(uint16_t value) {
	display_update_base(value, 10);
}

void display_update_hex(uint16_t value) {
	display_update_base(value, 16);
}

void display_render() {
	display_current_segment = (display_current_segment + 1) % (DISPLAY_NUMSEGMENTS * 2);
	
	/*
	uint8_t block;
	
	block = DISPLAY_SEGMENTS[display_current_segment] & 0xFF;
	SPI_0_write_block(&block, 1);
	hri_sercomspi_read_DATA_reg(SERCOM4);
	//hri_sercomspi_clear_interrupt_RXC_bit(SERCOM4);

	block = DISPLAY_SEGMENTS[display_current_segment] >> 8;
	SPI_0_write_block(&block, 1);
	hri_sercomspi_read_DATA_reg(SERCOM4);
	//hri_sercomspi_clear_interrupt_RXC_bit(SERCOM4);
	
	block = display_current_digits[display_current_segment];
	SPI_0_write_block(&block, 1);
	hri_sercomspi_read_DATA_reg(SERCOM4);
	//hri_sercomspi_clear_interrupt_RXC_bit(SERCOM4);
	*/
	/*
	block = DISPLAY_SEGMENTS[display_current_segment] & 0xFF;
	SPI_0_write_block(&block, 1);
	hri_sercomspi_read_DATA_reg(SERCOM4);
	hri_sercomspi_clear_interrupt_RXC_bit(SERCOM4);
	*/
	
	uint32_t val = (((uint32_t) display_current_digits[display_current_segment]) << 16) | DISPLAY_SEGMENTS[display_current_segment];
	//gpio_set_pin_level(DISPLAY_SS, false);
	SPI_0_exchange_block(&val, 3);
	//gpio_set_pin_level(DISPLAY_SS, true);
}