/*
 * hv_dc_supply.c
 *
 * Created: 09.07.2022 01:30:13
 *  Author: Christian
 */ 

#include <hv_dc_supply.h>

//hardware properties
#define HV_SW_TIMER TCC1
#define MAIN_CLOCK_SPEED 47972000
#define VCC 3.3
#define R24 22000
#define R27 680
#define HV_DC_SUPPLY_VOLTAGE_SENSE_MAX 0xFFF
#define TRANSFORMER_RATIO (10.0 / 1.0)
#define HV_DC_SUPPLY_BASE_VOLTAGE 12.0
#define HV_DC_SUPPLY_DIODE_VOLTAGE 1.1

//configurable properties
#define HV_DC_SUPPLY_BURST_END_RIPPLE_TIME 0.00000125 //s
#define HV_DC_SUPPYL_MAX_CYCLES 5000
#define HV_DC_SUPPLY_MIN_BURST_TIME 0.000015 //s
#define HV_DC_SUPPLY_MAX_BURST_TIME 0.005 //s
#define HV_DC_SUPPLY_BURST_SAFETY_MARGIN_TIME 0.000005 //s
//absolute maximum duty cycle should not exceed 0.0000025, exactly 6A are flowing through the transformers then
//#define HV_DC_SUPPLY_MIN_DUTY_CYCLE_TIME 0.0000018 //s
#define HV_DC_SUPPLY_MIN_DUTY_CYCLE_TIME 0.0000023 //s
#define HV_DC_SUPPLY_MAX_DUTY_CYCLE_TIME 0.0000023 //s
#define HV_DC_SUPPLY_ZERO_CHANGE_SAFETY_TIME 0.000002 //s
#define HV_DC_SUPPLY_TARGET_VOLTAGE 170.0 //V

//intermediate values
#define HALF_VCC VCC / 2.0
#define HV_DC_SUPPLY_MAX_VOLTAGE ((HALF_VCC / R27) * (R24 + R27) * TRANSFORMER_RATIO)
#define HV_DC_SUPPLY_VOLTAGE_SENSE_FACTOR ((HV_DC_SUPPLY_MAX_VOLTAGE - HV_DC_SUPPLY_BASE_VOLTAGE) / HV_DC_SUPPLY_VOLTAGE_SENSE_MAX)
#define HV_DC_SUPPLY_ADAPTED_TARGET_VOLTAGE (HV_DC_SUPPLY_TARGET_VOLTAGE + HV_DC_SUPPLY_DIODE_VOLTAGE - HV_DC_SUPPLY_BASE_VOLTAGE)
#define HV_DC_SUPPLY_MAX_BURST_CYCLES_DEF ((uint32_t) (HV_DC_SUPPLY_MAX_BURST_TIME * ((float) MAIN_CLOCK_SPEED) + 0.5))

//calculated properties scaled to uint
const uint16_t HV_DC_SUPPLY_BURST_END_RIPPLE_CYCLES = (uint16_t) (MAIN_CLOCK_SPEED * HV_DC_SUPPLY_BURST_END_RIPPLE_TIME);
const uint16_t HV_DC_SUPPLY_SENSE_TARGET = (uint16_t) (HV_DC_SUPPLY_ADAPTED_TARGET_VOLTAGE / HV_DC_SUPPLY_VOLTAGE_SENSE_FACTOR);
const uint16_t HV_DC_SUPPLY_DIODE_VOLTAGE_VALUE = (uint16_t) (HV_DC_SUPPLY_DIODE_VOLTAGE / HV_DC_SUPPLY_VOLTAGE_SENSE_FACTOR);
const uint32_t HV_DC_SUPPLY_CONDUCTION_TIME_FACTOR = (uint32_t) ((HV_DC_SUPPLY_BASE_VOLTAGE * TRANSFORMER_RATIO) / HV_DC_SUPPLY_VOLTAGE_SENSE_FACTOR);
const uint32_t HV_DC_SUPPLY_MIN_BURST_CYCLES = ((uint32_t) (HV_DC_SUPPLY_MIN_BURST_TIME * ((float) MAIN_CLOCK_SPEED) + 0.5));
const uint32_t HV_DC_SUPPLY_MAX_BURST_CYCLES = HV_DC_SUPPLY_MAX_BURST_CYCLES_DEF;
const uint16_t HV_DC_SUPPLY_BURST_SAFETY_MARGIN_CYCLES = ((uint16_t) (HV_DC_SUPPLY_BURST_SAFETY_MARGIN_TIME * ((float) MAIN_CLOCK_SPEED) + 0.5));
const uint16_t HV_DC_SUPPLY_MIN_DUTY_CYCLE_CYCLES = ((uint16_t) (HV_DC_SUPPLY_MIN_DUTY_CYCLE_TIME * ((float) MAIN_CLOCK_SPEED) + 0.5));
const uint16_t HV_DC_SUPPLY_MAX_DUTY_CYCLE_CYCLES = ((uint16_t) (HV_DC_SUPPLY_MAX_DUTY_CYCLE_TIME * ((float) MAIN_CLOCK_SPEED) + 0.5));
const uint32_t HV_DC_SUPPLY_ZERO_CHANGE_SAFETY_CYCLES = ((uint16_t) (HV_DC_SUPPLY_ZERO_CHANGE_SAFETY_TIME * ((float) MAIN_CLOCK_SPEED) + 0.5));

//volatile bool hv_dc_supply_enabled = false;
volatile uint16_t hv_dc_supply_counter = 0;
volatile uint16_t hv_dc_supply_duty_cycle = 0;
volatile int32_t hv_dc_supply_period = HV_DC_SUPPLY_MAX_BURST_CYCLES_DEF;
volatile int32_t hv_dc_supply_period_history = HV_DC_SUPPLY_MAX_BURST_CYCLES_DEF;
volatile int32_t hv_dc_supply_voltage = 0;
volatile uint32_t hv_dc_supply_zero_change_period = HV_DC_SUPPLY_MAX_BURST_CYCLES_DEF;

static inline void hv_dc_supply_set_duty_cycle(const uint16_t duty_cycle) {
	hv_dc_supply_duty_cycle = duty_cycle;
	hri_tcc_write_CCB_reg(HV_SW_TIMER, 1, duty_cycle);
	hri_tcc_write_CCB_reg(HV_SW_TIMER, 0, duty_cycle ? duty_cycle + HV_DC_SUPPLY_BURST_END_RIPPLE_CYCLES : 0xFFFFFF);
}

static inline void hv_dc_supply_set_period(const uint32_t period) {
	hv_dc_supply_period_history = hv_dc_supply_period;
	hv_dc_supply_period = period;
	hri_tcc_write_PERB_reg(HV_SW_TIMER, period);
}

static inline uint32_t hv_dc_supply_check_burst_time(const uint32_t cycles) {
	if (cycles >= HV_DC_SUPPLY_MAX_BURST_CYCLES) {
		return HV_DC_SUPPLY_MAX_BURST_CYCLES;
	}
	if (cycles < HV_DC_SUPPLY_MIN_BURST_CYCLES) {
		return HV_DC_SUPPLY_MIN_BURST_CYCLES;
	}
	return cycles;
}

static inline void hv_dc_supply_set_voltage_reading(const int32_t voltage) {
	if (hv_dc_supply_voltage != voltage) {
		//hv_dc_supply_zero_change_period = hv_dc_supply_check_burst_time(hv_dc_supply_period - (((hv_dc_supply_period_history - hv_dc_supply_period) * voltage) / (hv_dc_supply_voltage - voltage)) /*+ HV_DC_SUPPLY_ZERO_CHANGE_SAFETY_CYCLES*/);
	}
	hv_dc_supply_voltage = voltage;
}

static inline uint32_t hv_dc_supply_conduction_time(const uint32_t voltage) {
	return (hv_dc_supply_duty_cycle * HV_DC_SUPPLY_CONDUCTION_TIME_FACTOR) / (voltage + HV_DC_SUPPLY_DIODE_VOLTAGE_VALUE);
}

static inline uint16_t hv_dc_supply_conduction_cycles(const uint16_t voltage) {
	uint32_t result = hv_dc_supply_conduction_time(voltage) + HV_DC_SUPPLY_BURST_SAFETY_MARGIN_CYCLES;	
	return hv_dc_supply_check_burst_time(result);
}

void hv_dc_supply_sense(const struct adc_async_descriptor *const descr, const uint8_t channel) {
	uint16_t voltage = adc_data_read(descr);
	gpio_set_pin_level(GPIO2, true);
	gpio_set_pin_level(LED2, voltage < HV_DC_SUPPLY_SENSE_TARGET);
	hv_dc_supply_set_voltage_reading(voltage);
	if (voltage >= HV_DC_SUPPLY_SENSE_TARGET) {
		hv_dc_supply_set_period(hv_dc_supply_zero_change_period);
		gpio_set_pin_level(GPIO2, false);
	} else {
		uint16_t conduction_cycles = hv_dc_supply_conduction_cycles(voltage) + hv_dc_supply_duty_cycle;
		hv_dc_supply_set_period(conduction_cycles);
		gpio_set_pin_level(GPIO2, false);
	}
 }

void hv_dc_supply_enable_adc() {
	gpio_set_pin_direction(PWR_SENSE, GPIO_DIRECTION_OFF);
	gpio_set_pin_function(PWR_SENSE, PINMUX_PA02B_ADC_AIN0);

	gpio_set_pin_direction(HV_SENSE, GPIO_DIRECTION_OFF);
	gpio_set_pin_function(HV_SENSE, PINMUX_PA03B_ADC_AIN1);
	
	adc_async_set_inputs(&ADC_0, ADC_MUXPOS_AIN1, ADC_MUXNEG_AIN0, 0);
	
	adc_async_register_callback(&ADC_0, 0, ADC_ASYNC_CONVERT_CB, hv_dc_supply_sense);
	adc_async_enable_channel(&ADC_0, 0);
	
	adc_async_start_conversion(&ADC_0);
}

void hv_dc_supply_disable_adc() {
	adc_async_disable_channel(&ADC_0, 0);
	
	gpio_set_pin_function(PWR_SENSE, GPIO_PIN_FUNCTION_OFF);
	gpio_set_pin_function(HV_SENSE, GPIO_PIN_FUNCTION_OFF);
}

int count = 0;

void TCC1_Handler() {
	/*
	hri_tcc_intflag_reg_t intflag = hri_tcc_read_INTFLAG_reg(HV_SW_TIMER);
	if (intflag & TCC_INTFLAG_MC1) {
		hri_tcc_clear_interrupt_MC1_bit(HV_SW_TIMER);
		
		if (hv_dc_supply_enabled) {
			//gpio_set_pin_level(GPIO2, true);
		}
		
		//switch off power supply
		hv_dc_supply_counter++;
		if (hv_dc_supply_counter >= HV_DC_SUPPYL_MAX_CYCLES) {
			hv_dc_supply_enabled = false;
			hv_dc_supply_set_duty_cycle(0x0000); //0us
		}
	} else if (intflag & TCC_INTFLAG_MC0) {
		hri_tcc_clear_interrupt_MC0_bit(HV_SW_TIMER);
		//adc_async_start_conversion(&ADC_0);
	} else if (intflag & TCC_INTFLAG_OVF) {
		hri_tcc_clear_interrupt_OVF_bit(HV_SW_TIMER);
	}
	*/
	//only the MC1 interrupt is enabled, so no interrupt flags need to be checked
	hri_tcc_clear_interrupt_MC1_bit(HV_SW_TIMER);
	hv_dc_supply_counter++;
	if (hv_dc_supply_counter >= HV_DC_SUPPYL_MAX_CYCLES) {
		//hv_dc_supply_enabled = false;
		hv_dc_supply_set_duty_cycle(0x0000); //0us
	}
	gpio_set_pin_level(GPIO2, true);
	gpio_set_pin_level(GPIO2, false);
}

void hv_dc_supply_cancel() {
	//hv_dc_supply_enabled = false;
	hv_dc_supply_set_duty_cycle(0x0000); //0us
}

void hv_dc_supply_power_pulse() {
	count = 0;
	//hv_dc_supply_enabled = true;
	hv_dc_supply_counter = 0;
	hv_dc_supply_set_period(HV_DC_SUPPLY_MAX_BURST_CYCLES);
	hv_dc_supply_set_duty_cycle(HV_DC_SUPPLY_MIN_DUTY_CYCLE_CYCLES);
}

void hv_dc_supply_init_timer() {
	
	//hri_tcc_write_PER_reg(HV_SW_TIMER, 0x07B0); //41us
	//hri_tcc_write_PER_reg(HV_SW_TIMER, 0xFFFF); //1.36ms
	hri_tcc_write_PER_reg(HV_SW_TIMER, HV_DC_SUPPLY_MAX_BURST_CYCLES);
	hv_dc_supply_set_duty_cycle(0x0000); //3us
	
	hri_tcc_write_WAVE_reg(HV_SW_TIMER,
		  0 << TCC_WAVE_SWAP1_Pos
		| 0 << TCC_WAVE_SWAP0_Pos
		| 1 << TCC_WAVE_POL1_Pos
		| 0 << TCC_WAVE_POL0_Pos
		| 0 << TCC_WAVE_CICCEN1_Pos
		| 0 << TCC_WAVE_CICCEN0_Pos
		| 0 << TCC_WAVE_CIPEREN_Pos
		| 0 << TCC_WAVE_RAMP_Pos
		| TCC_WAVE_WAVEGEN_NPWM_Val << TCC_WAVE_WAVEGEN_Pos
	);

	gpio_set_pin_level(HV_SW, true);
	gpio_set_pin_direction(HV_SW, GPIO_DIRECTION_OUT);
	gpio_set_pin_drive_strength(HV_SW);
	//gpio_set_pin_level(HV_SW, true);
	gpio_set_pin_function(HV_SW, PINMUX_PA07E_TCC1_WO1);
	
	/*
	hri_tcc_write_PER_reg(HV_SW_TIMER, 0x07B0); //41us
	hv_dc_supply_set_duty_cycle(0x0000); //3us
	
	hri_tcc_write_WAVE_reg(HV_SW_TIMER,
		  0 << TCC_WAVE_SWAP1_Pos
		| 0 << TCC_WAVE_SWAP0_Pos
		| 1 << TCC_WAVE_POL1_Pos
		| 0 << TCC_WAVE_POL0_Pos
		| 0 << TCC_WAVE_CICCEN1_Pos
		| 0 << TCC_WAVE_CICCEN0_Pos
		| 0 << TCC_WAVE_CIPEREN_Pos
		| 0 << TCC_WAVE_RAMP_Pos
		| TCC_WAVE_WAVEGEN_NPWM_Val << TCC_WAVE_WAVEGEN_Pos
	);
	*/

	/*
	_pm_enable_bus_clock(PM_BUS_APBC, HV_SW_TIMER);
	_gclk_enable_channel(TCC1_GCLK_ID, GCLK_CLKCTRL_GEN_GCLK0_Val);
	*/
	
	/*
	struct tcc_cfg *cfg = _get_tcc_cfg(hw);
	if (cfg == NULL) {
		return ERR_NOT_FOUND;
	}
	*/
	/*
	if (!hri_tcc_is_syncing(HV_SW_TIMER, TCC_SYNCBUSY_SWRST)) {
		if (hri_tcc_get_CTRLA_reg(HV_SW_TIMER, TCC_CTRLA_ENABLE)) {
			hri_tcc_clear_CTRLA_ENABLE_bit(HV_SW_TIMER);
			hri_tcc_wait_for_sync(HV_SW_TIMER, TCC_SYNCBUSY_ENABLE);
		}
		hri_tcc_write_CTRLA_reg(HV_SW_TIMER, TCC_CTRLA_SWRST);
	}
	hri_tcc_wait_for_sync(HV_SW_TIMER, TCC_SYNCBUSY_SWRST);

	hri_tcc_write_CTRLA_reg(hw, cfg->ctrl_a);
	hri_tcc_set_CTRLB_reg(hw, cfg->ctrl_b);
	hri_tcc_write_DBGCTRL_reg(hw, cfg->dbg_ctrl);
	hri_tcc_write_EVCTRL_reg(hw, cfg->event_ctrl);
	hri_tcc_write_PER_reg(hw, cfg->per);
	hri_tcc_set_INTEN_OVF_bit(HV_SW_TIMER);

	_tcc_init_irq_param(hw, (void *)device);
	*/
	NVIC_DisableIRQ(TCC1_IRQn);
	NVIC_ClearPendingIRQ(TCC1_IRQn);
	NVIC_EnableIRQ(TCC1_IRQn);
}