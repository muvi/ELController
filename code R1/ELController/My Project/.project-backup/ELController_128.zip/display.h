/*
 * display.h
 *
 * Created: 2/6/2023 6:23:10 PM
 *  Author: Christian
 */ 


#ifndef DISPLAY_H_
#define DISPLAY_H_

#include <spi_lite.h>

#define DISPLAY_MAXVALUE 9

void display_init();
void display_update(uint8_t value);

#endif /* DISPLAY_H_ */