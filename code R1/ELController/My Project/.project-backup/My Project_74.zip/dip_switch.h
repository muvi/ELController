/*
 * dip_switch.h
 *
 * Created: 29.06.2022 17:58:17
 *  Author: Christian
 */ 


#ifndef DIP_SWITCH_H_
#define DIP_SWITCH_H_

#include <atmel_start.h>
#include <utils_ringbuffer.h>
#include <adc_util.h>

void dip_switch_read();

#endif /* DIP_SWITCH_H_ */