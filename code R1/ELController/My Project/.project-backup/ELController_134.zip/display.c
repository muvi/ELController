/*
 * display.c
 *
 * Created: 2/6/2023 6:23:25 PM
 *  Author: Christian
 */ 

#include <display.h>

const uint8_t DISPLAY_NUMBERS[DISPLAY_MAXVALUE + 1] = {0b10001000, 0b11011011, 0b10010100, 0b10010001, 0b11000011, 0b10100001, 0b10100000, 0b10011011, 0b10000000, 0b10000001};
//const uint8_t DISPLAY_NUMBERS[DISPLAY_MAXVALUE + 1] = {0b00000001, 0b00000010, 0b00000100, 0b00001000, 0b00010000, 0b00100000, 0b01000000, 0b10000000, 0b00000000, 0b11111111};
//const uint8_t DISPLAY_NUMBERS[DISPLAY_MAXVALUE] = {0b00010001, 0b11011011, 0b00101001, 0b10001001, 0b11000011, 0b10000101, 0b00000101, 0b11011001, 0b00000001, 0b10000001};
const uint8_t DISPLAY_DOT = 0b01111111;
//const uint8_t DISPLAY_NUMBERS[] = {0b11101110, 0b00100100, 0b11010110, 0b01110110, 0b00111100, 0b01111010, 0b11111010, 0b00100110, 0b11111110, 0b01111110};
//const uint8_t DISPLAY_DOT = 0b00000001;

void display_init() {
	SPI_0_enable();
}

void display_update(uint8_t value) {
	//hri_sercomspi_write_DATA_reg(SERCOM4, value);
	
	uint8_t val;
	if (value > DISPLAY_MAXVALUE) {
		val = DISPLAY_DOT;
	} else {
		val = DISPLAY_NUMBERS[value];
	}
	
	hri_sercomspi_write_DATA_reg(SERCOM4, 0x10101010);
	hri_sercomspi_write_DATA_reg(SERCOM4, val);
	//SPI_0_exchange_data(val);
	//SPI_0_exchange_data(val);
}