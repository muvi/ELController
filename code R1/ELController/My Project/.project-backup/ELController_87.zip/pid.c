/*
 * pid.c
 *
 * Created: 08.08.2022 21:17:39
 *  Author: Christian
 */ 

#include <pid.h>

PidController testController = PID_CONTROLLER(1, 1, 1, 20, 5, 5, 2, 1, 5, 5);

/*
inline void pid_controller_init(PidController* controller) {
	controller->last_error = 0;
	controller->last_integral_value = 0;
	controller->last_differential_value = 0;
}
*/

//PID_CONTROL_OUTPUT_T pid_controller_update(const PidController* controller) {
	
//}