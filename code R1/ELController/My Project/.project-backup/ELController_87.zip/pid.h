/*
 * pid.h
 *
 * Created: 08.08.2022 21:17:22
 *  Author: Christian
 */ 


#ifndef PID_H_
#define PID_H_

#define PID_MEASUREMENT_T uint16_t
#define PID_CONTROL_OUTPUT_T uint32_t

#include <atmel_start.h>

typedef struct {
		const PID_CONTROL_OUTPUT_T kp_factor;
		const PID_CONTROL_OUTPUT_T kp_divisor;
		const PID_CONTROL_OUTPUT_T ki_factor;
		const PID_CONTROL_OUTPUT_T ki_divisor;
		const PID_CONTROL_OUTPUT_T kd_factor;
		const PID_CONTROL_OUTPUT_T kd_divisor;
		const PID_CONTROL_OUTPUT_T kd_filter_factor;
		const PID_CONTROL_OUTPUT_T kd_filter_divisor;
		const PID_CONTROL_OUTPUT_T min;
		const PID_CONTROL_OUTPUT_T max;
		const PID_CONTROL_OUTPUT_T integral_min;
		const PID_CONTROL_OUTPUT_T integral_max;
		PID_MEASUREMENT_T last_error;
		//PID_MEASUREMENT_T last_measurement;
		PID_CONTROL_OUTPUT_T last_integral_value;
		PID_CONTROL_OUTPUT_T last_derivative_value;
	} PidController;


#define PID_CONTROLLER(kp, ki, kd, gain_resolution, integrator_min, integrator_max, derivative_filter_cutoff, sampling_time, min_output, max_output) { \
	.kp_factor = (PID_CONTROL_OUTPUT_T) (kp * gain_resolution), \
	.kp_divisor = gain_resolution, \
	.ki_factor = (PID_CONTROL_OUTPUT_T) (ki* gain_resolution * sampling_time), \
	.ki_divisor = 2.0 * gain_resolution, \
	.kd_factor = 2.0 * kd * gain_resolution, \
	.kd_divisor = ((2.0 * derivative_filter_cutoff) + sampling_time) * gain_resolution, \
	.kd_filter_factor = ((2.0 * derivative_filter_cutoff) - sampling_time), \
	.kd_filter_divisor = ((2.0 * derivative_filter_cutoff) + sampling_time), \
	.min = min_output, \
	.max = max_output, \
	.integral_min = integrator_min, \
	.integral_max = integrator_max \
}

inline void pid_controller_init(PidController* controller) {
	controller->last_error = 0;
	controller->last_integral_value = 0;
	controller->last_derivative_value = 0;
}

inline PID_CONTROL_OUTPUT_T pid_controller_update(PidController* controller, PID_MEASUREMENT_T error) {
	PID_CONTROL_OUTPUT_T proportional = (controller->kp_factor * error) / controller->kp_divisor;
	PID_CONTROL_OUTPUT_T integral = (controller->ki_factor * (error + controller->last_error)) / controller->ki_divisor + controller->last_integral_value;
	PID_CONTROL_OUTPUT_T derivative = (controller->kd_factor * (error - controller->last_error)) / controller->kd_divisor + (controller->kd_filter_factor * controller->last_derivative_value) / controller->kd_filter_divisor;

	//integrator anti-windup
	PID_CONTROL_OUTPUT_T integrator_limit;
	if (proportional < controller->integral_max) {
		integrator_limit = controller->integral_max - proportional;
	} else {
		integrator_limit = 0;
	}
	if (integral > integrator_limit) {
		integral = integrator_limit;
	}
	
	if (proportional > controller->integral_min) {
		integrator_limit = controller->integral_min - proportional;
	} else {
		integrator_limit = 0;
	}
	if (integral < integrator_limit) {
		integral = integrator_limit;
	}

	controller->last_error = error;
	controller->last_integral_value = integral;
	controller->last_derivative_value = derivative;
	
	PID_CONTROL_OUTPUT_T result = proportional + integral + derivative;
	if (result > controller->max) {
		return controller->max;
	}
	if (result < controller->min) {
		return controller->min;
	}
	return result;
}
 
#endif /* PID_H_ */