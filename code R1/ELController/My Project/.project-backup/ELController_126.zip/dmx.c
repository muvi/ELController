/*
 * dmx.c
 *
 * Created: 28.06.2022 20:41:10
 *  Author: Christian
 */ 
#include <dmx.h>


volatile unsigned short dmxNextAddress = 1;
volatile unsigned short dmxNextAddress2 = 1;
unsigned short dmxStartAddress = 1;
unsigned short currentChannel = 0;

void SERCOM5_Handler() {
	if (hri_sercomusart_get_interrupt_ERROR_bit(SERCOM5)) {
		hri_sercomusart_clear_interrupt_ERROR_bit(SERCOM5);
		hri_sercomusart_clear_STATUS_reg(SERCOM5, SERCOM_USART_STATUS_MASK);
		hri_sercomusart_read_DATA_reg(SERCOM5);
		currentChannel = 0;
		unsigned short newAddress = dmxNextAddress;
		if (newAddress == dmxNextAddress2) {
			dmxStartAddress = newAddress;
		}
	} else if (hri_sercomusart_get_interrupt_RXC_bit(SERCOM5)) {
		hri_sercomusart_clear_interrupt_RXC_bit(SERCOM5);
		if (hri_sercomusart_read_STATUS_reg(SERCOM5)
		    & (SERCOM_USART_STATUS_PERR | SERCOM_USART_STATUS_FERR | SERCOM_USART_STATUS_BUFOVF
		       | SERCOM_USART_STATUS_ISF | SERCOM_USART_STATUS_COLL)) {
			hri_sercomusart_clear_STATUS_reg(SERCOM5, SERCOM_USART_STATUS_MASK);
			hri_sercomusart_read_DATA_reg(SERCOM5);
			return;
		}
		uint8_t dmx_value = hri_sercomusart_read_DATA_reg(SERCOM5);
		
		if (currentChannel >= dmxStartAddress) {
			if (currentChannel < dmxStartAddress + DMX_CHANNELS) {
				
				//uint8_t dmx_value = descr->rx.buf[(descr->rx.write_index + descr->rx.size) & descr->rx.size];
				dmx[currentChannel - dmxStartAddress] = dmx_value;
				//gpio_set_pin_level(GPIO5, dmx_value);
			}
		}
		if (currentChannel == dmxStartAddress) {
			//gpio_set_pin_level(LED2, false);
		}
		if (currentChannel == dmxStartAddress + DMX_CHANNELS - 1) {
			//gpio_set_pin_level(LED2, true);
			dmx_received();
		}
		currentChannel++;
	}
}
/*
void dmx_error(const struct usart_async_descriptor *const descr) {
	currentChannel = 0;
	dmxStartAddress = dmxNextAddress;
}

void dmx_rx(const struct usart_async_descriptor *const descr) {
	//gpio_toggle_pin_level(GPIO5);
	
	if (currentChannel >= dmxStartAddress) {
		if (currentChannel < dmxStartAddress + DMX_CHANNELS) {
			uint8_t dmx_value = descr->rx.buf[(descr->rx.write_index + descr->rx.size) & descr->rx.size];
			dmx[currentChannel - dmxStartAddress] = dmx_value;
			gpio_set_pin_level(GPIO5, dmx_value);
		}
	}
	if (currentChannel == dmxStartAddress) {
		//gpio_set_pin_level(LED2, false);
	}
	if (currentChannel == dmxStartAddress + DMX_CHANNELS - 1) {
		//gpio_set_pin_level(LED2, true);
		dmx_received();
	}
	currentChannel++;
}
*/

void dmx_set_address(unsigned short address) {
	dmxNextAddress = address;
	dmxNextAddress2 = address;
}

void dmx_init() {
	NVIC_DisableIRQ(SERCOM5_IRQn);
	NVIC_ClearPendingIRQ(SERCOM5_IRQn);
	NVIC_SetPriority(SERCOM5_IRQn, INTERRUPT_PRIORITY_MEDIUM);
	NVIC_EnableIRQ(SERCOM5_IRQn);
	
	//usart_async_register_callback(uart, USART_ASYNC_ERROR_CB, dmx_error);
	//usart_async_register_callback(uart, USART_ASYNC_RXC_CB, dmx_rx);
	//usart_async_enable(uart);

/*
	NVIC_DisableIRQ(SERCOM5_IRQn);
	NVIC_ClearPendingIRQ(SERCOM5_IRQn);
	NVIC_SetPriority(SERCOM5_IRQn, INTERRUPT_PRIORITY_MEDIUM);
	NVIC_EnableIRQ(SERCOM5_IRQn);
	*/
}