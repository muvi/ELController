/*
 * output_channels.c
 *
 * Created: 24.08.2022 20:36:14
 *  Author: Christian
 */ 

#include <output_channels.h>

SineWave output_channels_wave_form[OUTPUT_CHANNELS_COUNT] = {
	SINE_WAVE(OUTPUT_CHANNELS_DEFAULT_FREQUENCY_VALUE_DEF, SINE_WAVE_MAX_VALUE),
	SINE_WAVE(OUTPUT_CHANNELS_DEFAULT_FREQUENCY_VALUE_DEF, SINE_WAVE_MAX_VALUE),
	SINE_WAVE(OUTPUT_CHANNELS_DEFAULT_FREQUENCY_VALUE_DEF, SINE_WAVE_MAX_VALUE),
	SINE_WAVE(OUTPUT_CHANNELS_DEFAULT_FREQUENCY_VALUE_DEF, SINE_WAVE_MAX_VALUE),
	SINE_WAVE(OUTPUT_CHANNELS_DEFAULT_FREQUENCY_VALUE_DEF, SINE_WAVE_MAX_VALUE),
	SINE_WAVE(OUTPUT_CHANNELS_DEFAULT_FREQUENCY_VALUE_DEF, SINE_WAVE_MAX_VALUE),
	SINE_WAVE(OUTPUT_CHANNELS_DEFAULT_FREQUENCY_VALUE_DEF, SINE_WAVE_MAX_VALUE),
	SINE_WAVE(OUTPUT_CHANNELS_DEFAULT_FREQUENCY_VALUE_DEF, SINE_WAVE_MAX_VALUE)
};

void output_channels_init_pins(const uint8_t positive_pin, const uint8_t negative_pin) {
	gpio_set_pin_level(positive_pin, true);
	gpio_set_pin_level(negative_pin, false);
	gpio_set_pin_direction(positive_pin, GPIO_DIRECTION_OUT);
	gpio_set_pin_direction(negative_pin, GPIO_DIRECTION_OUT);
	gpio_set_pin_drive_strength(positive_pin);
	gpio_set_pin_drive_strength(negative_pin);
}

void output_channels_init_1_and_2() {
	NVIC_DisableIRQ(TCC0_IRQn);
	NVIC_ClearPendingIRQ(TCC0_IRQn);

	hri_tcc_write_WAVE_reg(TCC0,
	0 << TCC_WAVE_SWAP3_Pos
	| 0 << TCC_WAVE_SWAP2_Pos
	| 0 << TCC_WAVE_SWAP1_Pos
	| 0 << TCC_WAVE_SWAP0_Pos
	| 1 << TCC_WAVE_POL3_Pos
	| 0 << TCC_WAVE_POL2_Pos
	| 1 << TCC_WAVE_POL1_Pos
	| 0 << TCC_WAVE_POL0_Pos
	| 0 << TCC_WAVE_CICCEN3_Pos
	| 0 << TCC_WAVE_CICCEN2_Pos
	| 0 << TCC_WAVE_CICCEN1_Pos
	| 0 << TCC_WAVE_CICCEN0_Pos
	| 0 << TCC_WAVE_CIPEREN_Pos
	| 0 << TCC_WAVE_RAMP_Pos
	| TCC_WAVE_WAVEGEN_NPWM_Val << TCC_WAVE_WAVEGEN_Pos
	);

	output_channels_init_pins(CH1P, CH1N);
	output_channels_init_pins(CH2P, CH2N);
	gpio_set_pin_function(CH1P, PINMUX_PA08E_TCC0_WO0);
	gpio_set_pin_function(CH1N, PINMUX_PA09E_TCC0_WO1);
	gpio_set_pin_function(CH2P, PINMUX_PA10F_TCC0_WO2);
	gpio_set_pin_function(CH2N, PINMUX_PA11F_TCC0_WO3);
	
	NVIC_SetPriority(TCC0_IRQn, INTERRUPT_PRIORITY_MEDIUM);
	NVIC_EnableIRQ(TCC0_IRQn);
}

void TCC0_Handler() {
	if (hri_tcc_get_INTFLAG_OVF_bit(TCC0)) {
		hri_tcc_clear_interrupt_OVF_bit(TCC0);

		//channel 1
		SineWaveSample next_value = sine_wave_next(&(output_channels_wave_form[0]));
		hri_tcc_write_CCB_reg_no_lock(TCC0, 2, next_value.pos);
		hri_tcc_write_CCB_reg_no_lock(TCC0, 3, next_value.neg);
		
		//channel 2
		next_value = sine_wave_next(&(output_channels_wave_form[1]));
		hri_tcc_write_CCB_reg_no_lock(TCC0, 0, next_value.pos);
		hri_tcc_write_CCB_reg_no_lock(TCC0, 1, next_value.neg);
		
		
		/*
		sine_wave_output_t next_value = sine_wave_next(&(output_channels_wave_form[0]));
		hri_tcc_write_CCB_reg_no_lock(TCC0, 0, next_value);
		hri_tcc_write_CCB_reg_no_lock(TCC0, 1, next_value);
		*/
		/*
		next_value = sine_wave_next(&(output_channels_wave_form[1]));
		hri_tcc_write_CCB_reg_no_lock(TCC0, 2, next_value);
		hri_tcc_write_CCB_reg_no_lock(TCC0, 3, next_value);
		*/
		
		gpio_set_pin_level(GPIO5, true);
	} else if (hri_tcc_get_INTFLAG_MC0_bit(TCC0)) {
		hri_tcc_clear_interrupt_MC0_bit(TCC0);
		gpio_set_pin_level(GPIO5, false);
	}
}

void output_channels_init() {
	output_channels_init_1_and_2();
}