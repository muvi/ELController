/*
 * hv_dc_supply.c
 *
 * Created: 09.07.2022 01:30:13
 *  Author: Christian
 */ 

#include <hv_dc_supply.h>

#define HV_SW_TIMER TCC1

void hv_dc_supply_sense(const struct adc_async_descriptor *const descr, const uint8_t channel) {
	
}

void hv_dc_supply_enable_adc() {
	gpio_set_pin_direction(PWR_SENSE, GPIO_DIRECTION_OFF);
	gpio_set_pin_function(PWR_SENSE, PINMUX_PA02B_ADC_AIN0);

	gpio_set_pin_direction(HV_SENSE, GPIO_DIRECTION_OFF);
	gpio_set_pin_function(HV_SENSE, PINMUX_PA03B_ADC_AIN1);
	
	adc_async_set_inputs(&ADC_0, ADC_MUXPOS_AIN1, ADC_MUXNEG_AIN0, 0);
	
	adc_async_register_callback(&ADC_0, 0, ADC_ASYNC_CONVERT_CB, hv_dc_supply_sense);
	adc_async_enable_channel(&ADC_0, 0);
}

void hv_dc_supply_disable_adc() {
	adc_async_disable_channel(&ADC_0, 0);
	
	gpio_set_pin_function(PWR_SENSE, GPIO_PIN_FUNCTION_OFF);
	gpio_set_pin_function(HV_SENSE, GPIO_PIN_FUNCTION_OFF);
}

void TCC1_Handler() {
	hri_tcc_intflag_reg_t intflag = hri_tcc_read_INTFLAG_reg(HV_SW_TIMER);
}

void hv_dc_supply_init_timer() {
	_pm_enable_bus_clock(PM_BUS_APBC, HV_SW_TIMER);
	_gclk_enable_channel(TCC1_GCLK_ID, GCLK_CLKCTRL_GEN_GCLK0_Val);
	
	/*
	struct tcc_cfg *cfg = _get_tcc_cfg(hw);
	if (cfg == NULL) {
		return ERR_NOT_FOUND;
	}
	*/
	/*
	if (!hri_tcc_is_syncing(HV_SW_TIMER, TCC_SYNCBUSY_SWRST)) {
		if (hri_tcc_get_CTRLA_reg(HV_SW_TIMER, TCC_CTRLA_ENABLE)) {
			hri_tcc_clear_CTRLA_ENABLE_bit(HV_SW_TIMER);
			hri_tcc_wait_for_sync(HV_SW_TIMER, TCC_SYNCBUSY_ENABLE);
		}
		hri_tcc_write_CTRLA_reg(HV_SW_TIMER, TCC_CTRLA_SWRST);
	}
	hri_tcc_wait_for_sync(HV_SW_TIMER, TCC_SYNCBUSY_SWRST);

	hri_tcc_write_CTRLA_reg(hw, cfg->ctrl_a);
	hri_tcc_set_CTRLB_reg(hw, cfg->ctrl_b);
	hri_tcc_write_DBGCTRL_reg(hw, cfg->dbg_ctrl);
	hri_tcc_write_EVCTRL_reg(hw, cfg->event_ctrl);
	hri_tcc_write_PER_reg(hw, cfg->per);
	hri_tcc_set_INTEN_OVF_bit(HV_SW_TIMER);

	_tcc_init_irq_param(hw, (void *)device);
	NVIC_DisableIRQ((IRQn_Type)cfg->irq);
	NVIC_ClearPendingIRQ((IRQn_Type)cfg->irq);
	NVIC_EnableIRQ((IRQn_Type)cfg->irq);
	*/
}