#include <atmel_start.h>
#include <io_util.h>
#include <dmx.h>
#include <dip_switch.h>
#include <hv_dc_supply.h>

void btn1_pressed() {
	hv_dc_supply_cancel();
}

void btn2_pressed() {
	hv_dc_supply_power_pulse();
}

void config_changed() {
	gpio_toggle_pin_level(LED1);
}

/*
void btn3_pressed() {
	state = 3;
}
*/

void dip_switch_data_ready(uint16_t data) {
	//gpio_set_pin_level(LED2, true);
	dmx_set_address(data & DMX_ADDRESS_MASK);
	//hv_dc_supply_enable_adc();
}

void SysTick_Handler() {
	//hv_dc_supply_disable_adc();
	//dip_switch_read();
}

void init() {
	gpio_set_pin_drive_strength(LED1);
	gpio_set_pin_drive_strength(LED2);
	
	ext_irq_register(BTN1, btn1_pressed);
	ext_irq_register(BTN2, btn2_pressed);
	
	dmx_set_address(1);
	dmx_init(&USART_0);
	
	hv_dc_supply_init_timer();
	hv_dc_supply_enable_adc();
	
	SysTick_Config(10000000);
}

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	init();
	//bool drive_strength = gpio_get_pin_drive_strength(LED2);

	while (1) {
	}
}
