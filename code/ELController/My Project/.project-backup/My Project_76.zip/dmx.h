#ifndef DMX_H
#define DMX_H

#include <atmel_start.h>

#define DMX_ADDRESS_BITS 9
#define DMX_ADDRESS_MASK ((2 << (DMX_ADDRESS_BITS + 1)) - 1)

void dmx_init(struct usart_async_descriptor *const uart);
void dmx_set_address(unsigned short address);

#endif