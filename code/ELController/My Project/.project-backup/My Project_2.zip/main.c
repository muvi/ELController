#include <atmel_start.h>
#include <io_util.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	gpio_set_pin_drive_strength(LED1);
	gpio_set_pin_drive_strength(LED2);
	gpio_toggle_pin_level(LED1);
	//bool drive_strength = gpio_get_pin_drive_strength(LED2);

	int state = 0;
	while (1) {
		//for (int i = 0; i < (drive_strength ? 2000 : 10000); i++) ;
		for (int i = 0; i < 50000; i++) ;
		state = (state + 1) % 4;
		gpio_toggle_pin_level(GPIO1);
		gpio_set_pin_level(LED1, !(state & 1));
		gpio_set_pin_level(LED2, !((state & 2) >> 1));
	}
}
