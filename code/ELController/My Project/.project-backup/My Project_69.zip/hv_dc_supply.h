/*
 * hv_dc_supply.h
 *
 * Created: 09.07.2022 01:29:59
 *  Author: Christian
 */ 


#ifndef HV_DC_SUPPLY_H_
#define HV_DC_SUPPLY_H_

#include <atmel_start.h>
#include <utils_ringbuffer.h>
#include <adc_util.h>
#include <hpl_pm_base.h>
#include <hpl_gclk_base.h>
#include <io_util.h>

void hv_dc_supply_enable_adc();
void hv_dc_supply_disable_adc();
void hv_dc_supply_init_timer();
void hv_dc_supply_power_pulse();

#endif /* HV_DC_SUPPLY_H_ */