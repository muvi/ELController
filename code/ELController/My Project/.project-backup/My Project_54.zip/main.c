#include <atmel_start.h>
#include <io_util.h>
#include <dmx.h>
#include <dip_switch.h>

volatile int state = 1;
volatile bool on = true;

void btn1_pressed() {
	state = 1;
}

void btn2_pressed() {
	state = 2;
}

/*
void btn3_pressed() {
	state = 3;
}
*/

void dip_switch_data_ready(uint16_t data) {
	dmx_set_address(data & DMX_ADDRESS_MASK);
}

void SysTick_Handler() {
	on = !on;

	dip_switch_read();
}

void init() {
	gpio_set_pin_drive_strength(LED1);
	gpio_set_pin_drive_strength(LED2);
	
	ext_irq_register(BTN1, btn1_pressed);
	ext_irq_register(BTN2, btn2_pressed);
	//ext_irq_register(BTN3, btn3_pressed);
	
	dmx_set_address(1);
	dmx_init(&USART_0);
	
	dip_switch_init_adc();
	
	SysTick_Config(1000000);
}

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	init();
	//bool drive_strength = gpio_get_pin_drive_strength(LED2);

	while (1) {
	}
}
