/*
 * base_util.h
 *
 * Created: 26.08.2022 15:17:26
 *  Author: Christian
 */ 


#ifndef BASE_UTIL_H_
#define BASE_UTIL_H_

#define MAIN_CLOCK_SPEED 47972000
#define VCC 3.3

#endif /* BASE_UTIL_H_ */