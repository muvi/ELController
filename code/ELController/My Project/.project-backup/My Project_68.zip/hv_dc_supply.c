/*
 * hv_dc_supply.c
 *
 * Created: 09.07.2022 01:30:13
 *  Author: Christian
 */ 

#include <hv_dc_supply.h>

#define HV_SW_TIMER TCC1

void hv_dc_supply_sense(const struct adc_async_descriptor *const descr, const uint8_t channel) {
	
}

void hv_dc_supply_enable_adc() {
	gpio_set_pin_direction(PWR_SENSE, GPIO_DIRECTION_OFF);
	gpio_set_pin_function(PWR_SENSE, PINMUX_PA02B_ADC_AIN0);

	gpio_set_pin_direction(HV_SENSE, GPIO_DIRECTION_OFF);
	gpio_set_pin_function(HV_SENSE, PINMUX_PA03B_ADC_AIN1);
	
	adc_async_set_inputs(&ADC_0, ADC_MUXPOS_AIN1, ADC_MUXNEG_AIN0, 0);
	
	adc_async_register_callback(&ADC_0, 0, ADC_ASYNC_CONVERT_CB, hv_dc_supply_sense);
	adc_async_enable_channel(&ADC_0, 0);
}

void hv_dc_supply_disable_adc() {
	adc_async_disable_channel(&ADC_0, 0);
	
	gpio_set_pin_function(PWR_SENSE, GPIO_PIN_FUNCTION_OFF);
	gpio_set_pin_function(HV_SENSE, GPIO_PIN_FUNCTION_OFF);
}

void TCC1_Handler() {
	gpio_toggle_pin_level(LED2);
	hri_tcc_intflag_reg_t intflag = hri_tcc_read_INTFLAG_reg(HV_SW_TIMER);
	if (intflag & TCC_INTFLAG_MC1) {
		hri_tcc_clear_interrupt_MC1_bit(HV_SW_TIMER);
		
		//switch off power supply
		hri_tcc_write_CC_reg(HV_SW_TIMER, 1, 0x0000); //0us
		
		gpio_set_pin_level(GPIO2, false);
	} else if (intflag & TCC_INTFLAG_OVF) {
		hri_tcc_clear_interrupt_OVF_bit(HV_SW_TIMER);
		gpio_set_pin_level(GPIO2, true);
	}
}

void hv_dc_supply_power_pulse() {
	hri_tcc_write_CC_reg(HV_SW_TIMER, 1, 0x0090); //3us
}

void hv_dc_supply_init_timer() {
	gpio_set_pin_level(HV_SW, true);
	gpio_set_pin_direction(HV_SW, GPIO_DIRECTION_OUT);
	gpio_set_pin_drive_strength(HV_SW);
	gpio_set_pin_level(HV_SW, true);
	gpio_set_pin_function(HV_SW, PINMUX_PA07E_TCC1_WO1);
	
	hri_tcc_write_PER_reg(HV_SW_TIMER, 0x07B0); //41us
	hri_tcc_write_CC_reg(HV_SW_TIMER, 1, 0x0000); //3us
	
	hri_tcc_write_WAVE_reg(HV_SW_TIMER,
		  0 << TCC_WAVE_SWAP1_Pos
		| 0 << TCC_WAVE_SWAP0_Pos
		| 1 << TCC_WAVE_POL1_Pos
		| 0 << TCC_WAVE_POL0_Pos
		| 0 << TCC_WAVE_CICCEN1_Pos
		| 0 << TCC_WAVE_CICCEN0_Pos
		| 0 << TCC_WAVE_CIPEREN_Pos
		| 0 << TCC_WAVE_RAMP_Pos
		| TCC_WAVE_WAVEGEN_NPWM_Val << TCC_WAVE_WAVEGEN_Pos
	);

	/*
	_pm_enable_bus_clock(PM_BUS_APBC, HV_SW_TIMER);
	_gclk_enable_channel(TCC1_GCLK_ID, GCLK_CLKCTRL_GEN_GCLK0_Val);
	*/
	
	/*
	struct tcc_cfg *cfg = _get_tcc_cfg(hw);
	if (cfg == NULL) {
		return ERR_NOT_FOUND;
	}
	*/
	/*
	if (!hri_tcc_is_syncing(HV_SW_TIMER, TCC_SYNCBUSY_SWRST)) {
		if (hri_tcc_get_CTRLA_reg(HV_SW_TIMER, TCC_CTRLA_ENABLE)) {
			hri_tcc_clear_CTRLA_ENABLE_bit(HV_SW_TIMER);
			hri_tcc_wait_for_sync(HV_SW_TIMER, TCC_SYNCBUSY_ENABLE);
		}
		hri_tcc_write_CTRLA_reg(HV_SW_TIMER, TCC_CTRLA_SWRST);
	}
	hri_tcc_wait_for_sync(HV_SW_TIMER, TCC_SYNCBUSY_SWRST);

	hri_tcc_write_CTRLA_reg(hw, cfg->ctrl_a);
	hri_tcc_set_CTRLB_reg(hw, cfg->ctrl_b);
	hri_tcc_write_DBGCTRL_reg(hw, cfg->dbg_ctrl);
	hri_tcc_write_EVCTRL_reg(hw, cfg->event_ctrl);
	hri_tcc_write_PER_reg(hw, cfg->per);
	hri_tcc_set_INTEN_OVF_bit(HV_SW_TIMER);

	_tcc_init_irq_param(hw, (void *)device);
	*/
	NVIC_DisableIRQ(TCC1_IRQn);
	NVIC_ClearPendingIRQ(TCC1_IRQn);
	NVIC_EnableIRQ(TCC1_IRQn);
}