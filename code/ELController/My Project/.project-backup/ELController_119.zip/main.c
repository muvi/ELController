#include <atmel_start.h>
#include <io_util.h>
#include <dmx.h>
#include <dip_switch.h>
#include <hv_dc_supply.h>
#include <pid.h>
#include <output_channels.h>

#define OUTPUT_CHANNEL_DMX_OFFSET 0

void btn1_pressed() {
	hv_dc_supply_disable_output();
	hv_dc_supply_cancel();
}

void btn2_pressed() {
	//make shure to call output_channels_init() first!
	hv_dc_supply_enable_output();
	hv_dc_supply_power_pulse();
}

void btn3_pressed() {
	//hv_dc_supply_enable_output();
	//hv_dc_supply_cancel();
}

void dip_switch_data_ready(uint16_t data) {
	gpio_toggle_pin_level(LED1);
	//gpio_set_pin_level(LED2, data == 1);
	dmx_set_address(data & DMX_ADDRESS_MASK);
}

uint8_t dmx_buffer[DMX_CHANNELS];
//volatile bool dmx_processing = false;
//volatile bool dmx_processing_enabled = false;

//volatile PidController controller_buf;

void dmx_received() {
	//gpio_toggle_pin_level(LED1);
	//gpio_set_pin_level(LED1, dmx[0] < 127);
	
	/*
	if (dmx[1] == 255) {
		hv_dc_supply_cancel();
	} else if (dmx[1] >= 127 && !dmx_processing) {
		for (int i =  0; i < DMX_CHANNELS - 1; i++) {
			dmx_buffer[i] = dmx[i];
		}
		
		if (dmx_processing_enabled) {
			if (dmx[0] >= 127) {
				gpio_toggle_pin_level(LED1);
			}
		}
		
		dmx_processing = true;
	}

	if (dmx[0] < 127) {
		gpio_set_pin_level(LED1, true);
	}
	
	if (dmx[0] == 255) {
		hv_dc_supply_power_pulse();
	}
	*/
	
	uint8_t dmx_pos = OUTPUT_CHANNEL_DMX_OFFSET;
	for (uint8_t i = 0; i < OUTPUT_CHANNELS_COUNT; i++) {
		uint8_t frequency = dmx[dmx_pos++];
		uint8_t amplitude = dmx[dmx_pos++];
		output_channels_update(i, frequency, amplitude);
	}
}

void SysTick_Handler() {
	dip_switch_read();
}

volatile uint32_t prio;

void init() {
	gpio_set_pin_drive_strength(LED1);
	gpio_set_pin_drive_strength(LED2);
	
	ext_irq_register(BTN1, btn1_pressed);
	ext_irq_register(BTN2, btn2_pressed);
	ext_irq_register(BTN3, btn3_pressed);
	
	dmx_set_address(1);
	dmx_init();
	
	hv_dc_supply_init();
	
	//pid_controller_tune(controller_buf, )
	
	dip_switch_init();
	
	output_channels_init();
	
	//lower SysTick priority to minimum, so the dip switch reading does not interfere with power supply regulation
	NVIC_SetPriority(SysTick_IRQn, INTERRUPT_PRIORITY_IDLE);
	//SysTick_Config(100000);
}

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	init();
	//bool drive_strength = gpio_get_pin_drive_strength(LED2);
	
	while (1) {
		//if (dmx_processing) {
			/*
			float voltage = (((float) (dmx_buffer[2])) / 255.0) * 70.0 + 100.0;
			HV_DC_SUPPLY_SENSE_TARGET_buf = HV_DC_SUPPLY_GENERATE_SENSE_TARGET(voltage);
		
			float duty_cycle_regulation_start = (((float) (dmx_buffer[3])) / 255.0) * 40.0 - 20.0;
			float duty_cycle_regulation_end = (((float) (dmx_buffer[4])) / 255.0) * 40.0 - 20.0;
			if (duty_cycle_regulation_end < duty_cycle_regulation_start) {
				duty_cycle_regulation_end = duty_cycle_regulation_start;
			}
		
			HV_DC_SUPPLY_DUTY_CYCLE_REGULATION_START_TARGET_buf = HV_DC_SUPPLY_GENERATE_SENSE_TARGET(voltage + HV_DC_SUPPLY_DUTY_CYCLE_REGULATION_START);
			HV_DC_SUPPLY_DUTY_CYCLE_REGULATION_END_TARGET_buf = HV_DC_SUPPLY_GENERATE_SENSE_TARGET(voltage + HV_DC_SUPPLY_DUTY_CYCLE_REGULATION_END);
			//HV_DC_SUPPLY_DUTY_CYCLE_REGULATION_START_TARGET_buf = HV_DC_SUPPLY_GENERATE_SENSE_TARGET(voltage + duty_cycle_regulation_start);
			//HV_DC_SUPPLY_DUTY_CYCLE_REGULATION_END_TARGET_buf = HV_DC_SUPPLY_GENERATE_SENSE_TARGET(voltage + duty_cycle_regulation_end);
			HV_DC_SUPPLY_PERIOD_REGULATION_START_TARGET_buf = HV_DC_SUPPLY_GENERATE_SENSE_TARGET(voltage + HV_DC_SUPPLY_PERIOD_REGULATION_START);
			HV_DC_SUPPLY_PERIOD_REGULATION_END_TARGET_buf = HV_DC_SUPPLY_GENERATE_SENSE_TARGET(voltage + HV_DC_SUPPLY_PERIOD_REGULATION_END);
			HV_DC_SUPPLY_VOLTAGE_AVERAGE_START_TARGET_buf = HV_DC_SUPPLY_GENERATE_SENSE_TARGET(voltage + HV_DC_SUPPLY_VOLTAGE_AVERAGE_START);
			HV_DC_SUPPLY_VOLTAGE_AVERAGE_END_TARGET_buf = HV_DC_SUPPLY_GENERATE_SENSE_TARGET(voltage + HV_DC_SUPPLY_VOLTAGE_AVERAGE_END);
			*/
		/*	
			dmx_processing = false;
			dmx_processing_enabled = true;
		}
		*/
	}
}
