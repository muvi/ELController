/*
 * dmx.c
 *
 * Created: 28.06.2022 20:41:10
 *  Author: Christian
 */ 
#include <dmx.h>

#define DMX_CHANNELS 8

unsigned short currentChannel = 0;
uint8_t dmx[DMX_CHANNELS];
unsigned short dmxStartAddress;

void dmx_error(const struct usart_async_descriptor *const descr) {
	currentChannel = 0;
}

volatile bool on2 = true;

void dmx_rx(const struct usart_async_descriptor *const descr) {
	if (currentChannel >= dmxStartAddress) {
		if (currentChannel < dmxStartAddress + DMX_CHANNELS) {
			//dmx[currentChannel - dmxStartAddress]
		}
	}
	//on2 = !on2;
	//gpio_set_pin_level(LED2, on2);
}

void dmx_set_address(unsigned short address) {
	dmxStartAddress = address;
}

void dmx_init(struct usart_async_descriptor *const uart) {
	//USART_ASYNC_RXC_CB, USART_ASYNC_TXC_CB, USART_ASYNC_ERROR_C
	usart_async_register_callback(uart, USART_ASYNC_ERROR_CB, dmx_error);
	usart_async_register_callback(uart, USART_ASYNC_RXC_CB, dmx_rx);
	usart_async_enable(uart);
}