/*
 * dmx.c
 *
 * Created: 28.06.2022 20:41:10
 *  Author: Christian
 */ 
#include <dmx.h>

#define DMX_CHANNELS 8

unsigned short currentChannel = 0;
uint8_t dmx[DMX_CHANNELS];
unsigned short dmxStartAddress;

void dmx_error(const struct usart_async_descriptor *const descr) {
	currentChannel = 0;
}

void dmx_received() {
	gpio_set_pin_level(LED1, dmx[0] < 127);
}

void dmx_rx(const struct usart_async_descriptor *const descr) {
	if (currentChannel >= dmxStartAddress) {
		if (currentChannel < dmxStartAddress + DMX_CHANNELS) {
			dmx[currentChannel - dmxStartAddress] = descr->rx.buf[(descr->rx.write_index + descr->rx.size) & descr->rx.size];
			if (dmx[currentChannel - dmxStartAddress] > 127) {
				gpio_toggle_pin_level(GPIO1);
			}
		}
	}
	if (currentChannel == dmxStartAddress) {
		gpio_set_pin_level(LED2, false);
	}
	if (currentChannel == dmxStartAddress + DMX_CHANNELS - 1) {
		gpio_set_pin_level(LED2, true);
		dmx_received();
	}
	currentChannel++;
}

void dmx_set_address(unsigned short address) {
	dmxStartAddress = address;
}

void dmx_init(struct usart_async_descriptor *const uart) {
	usart_async_register_callback(uart, USART_ASYNC_ERROR_CB, dmx_error);
	usart_async_register_callback(uart, USART_ASYNC_RXC_CB, dmx_rx);
	usart_async_enable(uart);
}