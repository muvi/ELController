/*
 * hv_dc_supply.c
 *
 * Created: 09.07.2022 01:30:13
 *  Author: Christian
 */ 

#include <hv_dc_supply.h>

//calculated properties scaled to uint
const uint16_t HV_DC_SUPPLY_BURST_END_RIPPLE_CYCLES = (uint16_t) (MAIN_CLOCK_SPEED * HV_DC_SUPPLY_BURST_END_RIPPLE_TIME);

volatile uint16_t HV_DC_SUPPLY_SENSE_TARGET = HV_DC_SUPPLY_GENERATE_SENSE_TARGET(HV_DC_SUPPLY_TARGET_VOLTAGE);
volatile uint16_t HV_DC_SUPPLY_LOCKOUT_OVERVOLTAGE_TARGET = HV_DC_SUPPLY_GENERATE_SENSE_TARGET(HV_DC_SUPPLY_LOCKOUT_OVERVOLTAGE);
volatile uint16_t HV_DC_SUPPLY_DUTY_CYCLE_REGULATION_START_TARGET = HV_DC_SUPPLY_GENERATE_SENSE_TARGET(HV_DC_SUPPLY_TARGET_VOLTAGE + HV_DC_SUPPLY_DUTY_CYCLE_REGULATION_START);
volatile uint16_t HV_DC_SUPPLY_DUTY_CYCLE_REGULATION_END_TARGET = HV_DC_SUPPLY_GENERATE_SENSE_TARGET(HV_DC_SUPPLY_TARGET_VOLTAGE + HV_DC_SUPPLY_DUTY_CYCLE_REGULATION_END);
volatile uint16_t HV_DC_SUPPLY_PERIOD_REGULATION_START_TARGET = HV_DC_SUPPLY_GENERATE_SENSE_TARGET(HV_DC_SUPPLY_TARGET_VOLTAGE + HV_DC_SUPPLY_PERIOD_REGULATION_START);
volatile uint16_t HV_DC_SUPPLY_PERIOD_REGULATION_END_TARGET = HV_DC_SUPPLY_GENERATE_SENSE_TARGET(HV_DC_SUPPLY_TARGET_VOLTAGE + HV_DC_SUPPLY_PERIOD_REGULATION_END);
volatile uint16_t HV_DC_SUPPLY_VOLTAGE_AVERAGE_START_TARGET = HV_DC_SUPPLY_GENERATE_SENSE_TARGET(HV_DC_SUPPLY_TARGET_VOLTAGE + HV_DC_SUPPLY_VOLTAGE_AVERAGE_START);
volatile uint16_t HV_DC_SUPPLY_VOLTAGE_AVERAGE_END_TARGET = HV_DC_SUPPLY_GENERATE_SENSE_TARGET(HV_DC_SUPPLY_TARGET_VOLTAGE + HV_DC_SUPPLY_VOLTAGE_AVERAGE_END);

const uint16_t HV_DC_SUPPLY_DIODE_VOLTAGE_VALUE = (uint16_t) (HV_DC_SUPPLY_DIODE_VOLTAGE / HV_DC_SUPPLY_VOLTAGE_SENSE_FACTOR);
const uint32_t HV_DC_SUPPLY_CONDUCTION_TIME_FACTOR = (uint32_t) ((HV_DC_SUPPLY_BASE_VOLTAGE * TRANSFORMER_RATIO) / HV_DC_SUPPLY_VOLTAGE_SENSE_FACTOR);
const uint32_t HV_DC_SUPPLY_MIN_BURST_CYCLES = ((uint32_t) (HV_DC_SUPPLY_MIN_BURST_TIME * ((float) MAIN_CLOCK_SPEED) + 0.5));
const uint32_t HV_DC_SUPPLY_MAX_BURST_CYCLES = HV_DC_SUPPLY_MAX_BURST_CYCLES_DEF;
const uint32_t HV_DC_SUPPLY_SUSTAIN_MODE_BURST_CYCLES = ((uint32_t) (HV_DC_SUPPLY_SUSTAIN_MODE_BURST_TIME * ((float) MAIN_CLOCK_SPEED) + 0.5));
const uint16_t HV_DC_SUPPLY_BURST_SAFETY_MARGIN_CYCLES = ((uint16_t) (HV_DC_SUPPLY_BURST_SAFETY_MARGIN_TIME * ((float) MAIN_CLOCK_SPEED) + 0.5));
const uint16_t HV_DC_SUPPLY_MIN_DUTY_CYCLE_CYCLES = ((uint16_t) (HV_DC_SUPPLY_MIN_DUTY_CYCLE_TIME * ((float) MAIN_CLOCK_SPEED) + 0.5));
const uint16_t HV_DC_SUPPLY_MAX_DUTY_CYCLE_CYCLES = ((uint16_t) (HV_DC_SUPPLY_MAX_DUTY_CYCLE_TIME * ((float) MAIN_CLOCK_SPEED) + 0.5));
const uint16_t HV_DC_SUPPLY_MIN_MEASURABLE_DUTY_CYCLE_CYCLES = ((uint16_t) (HV_DC_SUPPLY_MIN_MEASURABLE_DUTY_CYCLE_TIME * ((float) MAIN_CLOCK_SPEED) + 0.5));
//const uint32_t HV_DC_SUPPLY_ZERO_CHANGE_SAFETY_CYCLES = ((uint16_t) (HV_DC_SUPPLY_ZERO_CHANGE_SAFETY_TIME * ((float) MAIN_CLOCK_SPEED) + 0.5));


volatile bool hv_dc_supply_enabled = false;
volatile bool hv_dc_supply_measurable = false;
volatile bool hv_dc_supply_next_cycle_measurable = false;
volatile uint16_t hv_dc_supply_counter = 0;
volatile uint16_t hv_dc_supply_non_measurable_counter = 0;
volatile uint16_t hv_dc_supply_non_measurable_max = 0;
volatile uint32_t hv_dc_supply_next_measurable_period = HV_DC_SUPPLY_MAX_BURST_CYCLES_DEF;

volatile uint32_t hv_dc_supply_voltage_average = 0;
volatile uint8_t hv_dc_supply_voltage_average_counter = 0;

static inline uint16_t hv_dc_supply_set_voltage_average(const uint16_t voltage) {
	if (voltage >= HV_DC_SUPPLY_VOLTAGE_AVERAGE_START_TARGET && voltage <= HV_DC_SUPPLY_VOLTAGE_AVERAGE_END_TARGET) {
		gpio_set_pin_level(LED2, false);
		hv_dc_supply_voltage_average_counter++;
		if (hv_dc_supply_voltage_average_counter == 1) {
			hv_dc_supply_voltage_average = voltage << HV_DC_SUPPLY_VOLTAGE_AVERAGE_FRACTIONAL_BITS;
			return voltage;
		} else {
			//local variable to prevent multiple volatile reads
			uint32_t average = ((hv_dc_supply_voltage_average * HV_DC_SUPPLY_VOLTAGE_AVERAGE_HISTORY_WEIGHT) + (voltage << HV_DC_SUPPLY_VOLTAGE_AVERAGE_FRACTIONAL_BITS)) / (HV_DC_SUPPLY_VOLTAGE_AVERAGE_HISTORY_WEIGHT + 1);
			hv_dc_supply_voltage_average = average;
			if (hv_dc_supply_voltage_average_counter >= HV_DC_SUPPLY_VOLTAGE_AVERAGE_MIN_SAMPLES) {
				return average >> HV_DC_SUPPLY_VOLTAGE_AVERAGE_FRACTIONAL_BITS;
			} else {
				return voltage;
			}
		}
	} else {
		gpio_set_pin_level(LED2, true);
		hv_dc_supply_voltage_average_counter = 0;
		return voltage;
	}
}

static inline void hv_dc_supply_set_timer(const uint16_t duty_cycle, const uint32_t period, const uint16_t non_measurable_cycles, const uint32_t next_measurable_period) {
	//if there is a pending update, do that first
	if (!hri_tcc_get_STATUS_PERBV_bit(HV_SW_TIMER)) {
		hri_tcc_set_CTRLB_LUPD_bit(HV_SW_TIMER);

		bool measurable = duty_cycle >= HV_DC_SUPPLY_MIN_MEASURABLE_DUTY_CYCLE_CYCLES;
		if (!measurable) {
			hv_dc_supply_non_measurable_counter = 0;
			hv_dc_supply_non_measurable_max = non_measurable_cycles;
			hv_dc_supply_next_measurable_period = next_measurable_period;
		}
	
		hri_tcc_write_CCB_reg(HV_SW_TIMER, 1, duty_cycle);
		hri_tcc_write_CCB_reg(HV_SW_TIMER, 0, measurable ? duty_cycle + HV_DC_SUPPLY_BURST_END_RIPPLE_CYCLES : 0xFFFFFF);
		hri_tcc_write_PERB_reg(HV_SW_TIMER, period);
		//hri_tcc_write_PERB_reg(HV_SW_TIMER, HV_DC_SUPPLY_MIN_BURST_CYCLES);

		hv_dc_supply_next_cycle_measurable = measurable;
		if (!measurable) {
			hv_dc_supply_measurable = false;
		}

		hri_tcc_clear_CTRLB_LUPD_bit(HV_SW_TIMER);
		
		//gpio_set_pin_level(LED1, !measurable);
	}
	//gpio_set_pin_level(GPIO2, duty_cycle == HV_DC_SUPPLY_MIN_DUTY_CYCLE_CYCLES);
}

static inline uint32_t hv_dc_supply_check_min_max(const uint32_t value, const uint32_t min, const uint32_t max) {
	if (value < min) {
		return min;
	}
	if (value > max) {
		return max;
	}
	return value;
}

/*
static inline void hv_dc_supply_set_voltage_reading(const int32_t voltage) {
	if (hv_dc_supply_voltage != voltage) {
		hv_dc_supply_zero_change_period = hv_dc_supply_check_burst_time(hv_dc_supply_period - (((hv_dc_supply_period_history - hv_dc_supply_period) * voltage) / (hv_dc_supply_voltage - voltage)));
	}
	hv_dc_supply_voltage = voltage;
}
*/

static inline uint32_t hv_dc_supply_conduction_time(const uint32_t voltage, const uint32_t duty_cycle) {
	return (duty_cycle * HV_DC_SUPPLY_CONDUCTION_TIME_FACTOR) / (voltage + HV_DC_SUPPLY_DIODE_VOLTAGE_VALUE);
}

static inline uint16_t hv_dc_supply_conduction_cycles(const uint16_t voltage, const uint16_t duty_cycle) {
	return hv_dc_supply_conduction_time(voltage, duty_cycle) + HV_DC_SUPPLY_BURST_SAFETY_MARGIN_CYCLES + duty_cycle;
}

//swap time_min and time_max to regulate down / get less time with higher voltage
static inline int32_t hv_dc_supply_regulate(const int32_t voltage, const int32_t voltage_min, const int32_t voltage_max, const int32_t time_min, const int32_t time_max) {
	if (voltage >= voltage_min) {
		if (voltage <= voltage_max) {
			return time_min + (((time_max - time_min) * (voltage - voltage_min)) / (voltage_max - voltage_min));
		} else {
			return time_max;
		}
	} else {
		return time_min;
	}
}

void hv_dc_supply_sense(const uint16_t voltage) {
	if (!hv_dc_supply_enabled || !hv_dc_supply_measurable) {
		return;
	}
	
	//overvoltage lockout
	if (voltage >= HV_DC_SUPPLY_LOCKOUT_OVERVOLTAGE_TARGET) {
		hv_dc_supply_cancel();
		return;
	}
	
	uint16_t averaged_voltage = hv_dc_supply_set_voltage_average(voltage);
	
	uint16_t duty_cycle = hv_dc_supply_regulate(averaged_voltage, HV_DC_SUPPLY_DUTY_CYCLE_REGULATION_START_TARGET, HV_DC_SUPPLY_DUTY_CYCLE_REGULATION_END_TARGET, HV_DC_SUPPLY_MAX_DUTY_CYCLE_CYCLES, HV_DC_SUPPLY_MIN_DUTY_CYCLE_CYCLES);
	uint32_t period = HV_DC_SUPPLY_MIN_BURST_CYCLES;
	//uint32_t period = hv_dc_supply_regulate(voltage, HV_DC_SUPPLY_PERIOD_REGULATION_START_TARGET, HV_DC_SUPPLY_PERIOD_REGULATION_END_TARGET, HV_DC_SUPPLY_MIN_BURST_CYCLES, HV_DC_SUPPLY_SUSTAIN_MODE_BURST_CYCLES);
	
	uint16_t non_measurable_cycles;
	uint32_t next_measurable_cycle_period;
	if (voltage >= HV_DC_SUPPLY_NON_MEASURABLE_CYCLE_REGULATION_START_TARGET) {
		non_measurable_cycles = HV_DC_SUPPLY_MAX_NON_MEASURABLE_CYCLES; //hv_dc_supply_regulate(voltage, HV_DC_SUPPLY_NON_MEASURABLE_CYCLE_REGULATION_START_TARGET, HV_DC_SUPPLY_NON_MEASURABLE_CYCLE_REGULATION_END_TARGET, 1, HV_DC_SUPPLY_MAX_NON_MEASURABLE_CYCLES);
		next_measurable_cycle_period = hv_dc_supply_check_min_max(hv_dc_supply_conduction_cycles(averaged_voltage, HV_DC_SUPPLY_MIN_MEASURABLE_DUTY_CYCLE_CYCLES), period, HV_DC_SUPPLY_MAX_BURST_CYCLES);
	} else {
		non_measurable_cycles = 0;
		next_measurable_cycle_period = HV_DC_SUPPLY_MAX_BURST_CYCLES;
	}
	
	if (period < HV_DC_SUPPLY_MAX_BURST_CYCLES) {
		period = hv_dc_supply_check_min_max(hv_dc_supply_conduction_cycles(averaged_voltage, duty_cycle), period, HV_DC_SUPPLY_MAX_BURST_CYCLES);
	}
	
	hv_dc_supply_set_timer(duty_cycle, period, non_measurable_cycles, next_measurable_cycle_period);
	
	//gpio_set_pin_level(LED2, averaged_voltage < HV_DC_SUPPLY_SENSE_TARGET);
	gpio_set_pin_level(GPIO2, voltage >= HV_DC_SUPPLY_SENSE_TARGET);
	//hv_dc_supply_set_voltage_reading(voltage);
	/*if (voltage >= HV_DC_SUPPLY_SENSE_TARGET) {
		hv_dc_supply_set_timer(HV_DC_SUPPLY_MIN_DUTY_CYCLE_CYCLES, HV_DC_SUPPLY_SUSTAIN_MODE_BURST_CYCLES);
	} else {
		uint16_t conduction_cycles = hv_dc_supply_check_min_max(hv_dc_supply_conduction_cycles(voltage, HV_DC_SUPPLY_MAX_DUTY_CYCLE_CYCLES), HV_DC_SUPPLY_MIN_BURST_CYCLES, HV_DC_SUPPLY_MAX_BURST_CYCLES);
		hv_dc_supply_set_timer(HV_DC_SUPPLY_MAX_DUTY_CYCLE_CYCLES, conduction_cycles);
	}*/
 }

void ADC_Handler() {
	hri_adc_clear_interrupt_RESRDY_bit(ADC);
	uint16_t data = hri_adc_read_RESULT_reg(ADC);
	hv_dc_supply_sense(data);
}

void hv_dc_supply_enable_adc() {
	gpio_set_pin_direction(PWR_SENSE, GPIO_DIRECTION_OFF);
	gpio_set_pin_function(PWR_SENSE, PINMUX_PA02B_ADC_AIN0);

	gpio_set_pin_direction(HV_SENSE, GPIO_DIRECTION_OFF);
	gpio_set_pin_function(HV_SENSE, PINMUX_PA03B_ADC_AIN1);
	
	adc_async_set_inputs(&ADC_0, ADC_MUXPOS_AIN1, ADC_MUXNEG_AIN0, 0);
	
	//adc_async_register_callback(&ADC_0, 0, ADC_ASYNC_CONVERT_CB, hv_dc_supply_sense);
	hri_adc_write_INTEN_RESRDY_bit(ADC, true);
	adc_async_enable_channel(&ADC_0, 0);
	
	//adc_async_start_conversion(&ADC_0);
}

int count = 0;

void TCC1_Handler() {
	/*
	hri_tcc_intflag_reg_t intflag = hri_tcc_read_INTFLAG_reg(HV_SW_TIMER);
	if (intflag & TCC_INTFLAG_MC1) {
		hri_tcc_clear_interrupt_MC1_bit(HV_SW_TIMER);
		
		if (hv_dc_supply_enabled) {
			//gpio_set_pin_level(GPIO2, true);
		}
		
		//switch off power supply
		hv_dc_supply_counter++;
		if (hv_dc_supply_counter >= HV_DC_SUPPYL_MAX_CYCLES) {
			hv_dc_supply_enabled = false;
			hv_dc_supply_set_duty_cycle(0x0000); //0us
		}
	} else if (intflag & TCC_INTFLAG_MC0) {
		hri_tcc_clear_interrupt_MC0_bit(HV_SW_TIMER);
		//adc_async_start_conversion(&ADC_0);
	} else if (intflag & TCC_INTFLAG_OVF) {
		hri_tcc_clear_interrupt_OVF_bit(HV_SW_TIMER);
	}
	*/
	//only the MC1 interrupt is enabled, so no interrupt flags need to be checked
	hri_tcc_clear_interrupt_MC1_bit(HV_SW_TIMER);
	//if (hv_dc_supply_enabled) {
	hv_dc_supply_counter++;
	if (!hv_dc_supply_enabled || hv_dc_supply_counter >= HV_DC_SUPPLY_MAX_CYCLES) {
		hv_dc_supply_cancel();
	} else {
		if (!hv_dc_supply_measurable) {
			hv_dc_supply_non_measurable_counter++;
			if (hv_dc_supply_non_measurable_counter >= hv_dc_supply_non_measurable_max) {
				hv_dc_supply_set_timer(HV_DC_SUPPLY_MIN_MEASURABLE_DUTY_CYCLE_CYCLES, hv_dc_supply_next_measurable_period, 0, HV_DC_SUPPLY_MAX_BURST_CYCLES);
			}
		}
		hv_dc_supply_measurable = hv_dc_supply_next_cycle_measurable;
	}
	
	//}
	//gpio_set_pin_level(GPIO2, true);
	//gpio_set_pin_level(GPIO2, false);
}

void hv_dc_supply_cancel() {
	hv_dc_supply_enabled = false;
	//CAUTION: This step can be skipped by a pending update. Sometimes, it has to be done again in TCC1_Handler
	hv_dc_supply_set_timer(0x000000, HV_DC_SUPPLY_MAX_BURST_CYCLES, 0, HV_DC_SUPPLY_MAX_BURST_CYCLES);
	//gpio_set_pin_level(LED2, true);
	//hv_dc_supply_set_duty_cycle(0x0000); //0us
}

void hv_dc_supply_power_pulse() {
	count = 0;
	hv_dc_supply_enabled = true;
	hv_dc_supply_counter = 0;
	hv_dc_supply_set_timer(HV_DC_SUPPLY_MAX_DUTY_CYCLE_CYCLES, HV_DC_SUPPLY_MAX_BURST_CYCLES, 0, HV_DC_SUPPLY_MAX_BURST_CYCLES);
	/*
	hv_dc_supply_set_period(HV_DC_SUPPLY_MAX_BURST_CYCLES);
	hv_dc_supply_set_duty_cycle(HV_DC_SUPPLY_MAX_DUTY_CYCLE_CYCLES);
	*/
}

void hv_dc_supply_init_timer() {
	
	//hri_tcc_write_PER_reg(HV_SW_TIMER, 0x07B0); //41us
	//hri_tcc_write_PER_reg(HV_SW_TIMER, 0xFFFF); //1.36ms
	hri_tcc_write_PER_reg(HV_SW_TIMER, HV_DC_SUPPLY_MAX_BURST_CYCLES);
	hri_tcc_write_CC_reg(HV_SW_TIMER, 1, 0x000000);
	hri_tcc_write_CC_reg(HV_SW_TIMER, 0, 0xFFFFFF);
	//hv_dc_supply_set_duty_cycle(0x0000); //3us
	
	hri_tcc_write_WAVE_reg(HV_SW_TIMER,
		  0 << TCC_WAVE_SWAP1_Pos
		| 0 << TCC_WAVE_SWAP0_Pos
		| 1 << TCC_WAVE_POL1_Pos
		| 0 << TCC_WAVE_POL0_Pos
		| 0 << TCC_WAVE_CICCEN1_Pos
		| 0 << TCC_WAVE_CICCEN0_Pos
		| 0 << TCC_WAVE_CIPEREN_Pos
		| 0 << TCC_WAVE_RAMP_Pos
		| TCC_WAVE_WAVEGEN_NPWM_Val << TCC_WAVE_WAVEGEN_Pos
	);

	gpio_set_pin_level(HV_SW, true);
	gpio_set_pin_direction(HV_SW, GPIO_DIRECTION_OUT);
	gpio_set_pin_drive_strength(HV_SW);
	//gpio_set_pin_level(HV_SW, true);
	gpio_set_pin_function(HV_SW, PINMUX_PA07E_TCC1_WO1);
	
	/*
	hri_tcc_write_PER_reg(HV_SW_TIMER, 0x07B0); //41us
	hv_dc_supply_set_duty_cycle(0x0000); //3us
	
	hri_tcc_write_WAVE_reg(HV_SW_TIMER,
		  0 << TCC_WAVE_SWAP1_Pos
		| 0 << TCC_WAVE_SWAP0_Pos
		| 1 << TCC_WAVE_POL1_Pos
		| 0 << TCC_WAVE_POL0_Pos
		| 0 << TCC_WAVE_CICCEN1_Pos
		| 0 << TCC_WAVE_CICCEN0_Pos
		| 0 << TCC_WAVE_CIPEREN_Pos
		| 0 << TCC_WAVE_RAMP_Pos
		| TCC_WAVE_WAVEGEN_NPWM_Val << TCC_WAVE_WAVEGEN_Pos
	);
	*/

	/*
	_pm_enable_bus_clock(PM_BUS_APBC, HV_SW_TIMER);
	_gclk_enable_channel(TCC1_GCLK_ID, GCLK_CLKCTRL_GEN_GCLK0_Val);
	*/
	
	/*
	struct tcc_cfg *cfg = _get_tcc_cfg(hw);
	if (cfg == NULL) {
		return ERR_NOT_FOUND;
	}
	*/
	/*
	if (!hri_tcc_is_syncing(HV_SW_TIMER, TCC_SYNCBUSY_SWRST)) {
		if (hri_tcc_get_CTRLA_reg(HV_SW_TIMER, TCC_CTRLA_ENABLE)) {
			hri_tcc_clear_CTRLA_ENABLE_bit(HV_SW_TIMER);
			hri_tcc_wait_for_sync(HV_SW_TIMER, TCC_SYNCBUSY_ENABLE);
		}
		hri_tcc_write_CTRLA_reg(HV_SW_TIMER, TCC_CTRLA_SWRST);
	}
	hri_tcc_wait_for_sync(HV_SW_TIMER, TCC_SYNCBUSY_SWRST);

	hri_tcc_write_CTRLA_reg(hw, cfg->ctrl_a);
	hri_tcc_set_CTRLB_reg(hw, cfg->ctrl_b);
	hri_tcc_write_DBGCTRL_reg(hw, cfg->dbg_ctrl);
	hri_tcc_write_EVCTRL_reg(hw, cfg->event_ctrl);
	hri_tcc_write_PER_reg(hw, cfg->per);
	hri_tcc_set_INTEN_OVF_bit(HV_SW_TIMER);

	_tcc_init_irq_param(hw, (void *)device);
	*/
	NVIC_DisableIRQ(TCC1_IRQn);
	NVIC_ClearPendingIRQ(TCC1_IRQn);
	NVIC_EnableIRQ(TCC1_IRQn);
}